<?php
/**
 * DONGM Workspace v6.0 - Module 3: API Router
 * Crafted by Đặng Minh Đông
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/core.php';

if (empty($_SESSION['dongm_auth'])) {
    safe_json_out(['status' => 'error', 'message' => 'Phiên đăng nhập đã hết hạn. Vui lòng tải lại trang!']);
}

// Xử lý Xuất file .SQL (GET Download)
if (isset($_GET['mysql_export'])) {
    if (empty($_SESSION['dongm_db'])) exit('Chưa kết nối MySQL.');
    try {
        $cfg = $_SESSION['dongm_db'];
        $dbWrap = get_db_connection($cfg);
        $dbName = $cfg['db'];
        $targetTable = trim($_GET['table'] ?? '');

        $tables = [];
        if ($targetTable !== '') {
            $tables[] = $targetTable;
        } else {
            $tRows = run_simple_Fetch($dbWrap, "SHOW TABLES");
            foreach ($tRows as $r) $tables[] = reset($r);
        }

        $filename = ($targetTable ? $targetTable : $dbName) . '_' . date('H-i-s_d-m-Y') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        echo "-- DONGM phpMyAdmin SQL Dump (" . $APP_VERSION . ")\n";
        echo "-- Database: `" . $dbName . "`\n";
        echo "-- Date: " . date('Y-m-d H:i:s') . "\n\n";
        echo "SET NAMES utf8mb4;\n";
        echo "SET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables as $t) {
            $cleanT = str_replace('`', '', $t);
            $createRows = run_simple_Fetch($dbWrap, "SHOW CREATE TABLE `{$cleanT}`");
            $createSql = $createRows[0]['Create Table'] ?? '';
            echo "-- ----------------------------\n";
            echo "-- Table structure for `{$cleanT}`\n";
            echo "-- ----------------------------\n";
            echo "DROP TABLE IF EXISTS `{$cleanT}`;\n";
            echo $createSql . ";\n\n";

            $dataRows = run_simple_Fetch($dbWrap, "SELECT * FROM `{$cleanT}`");
            if (!empty($dataRows)) {
                echo "-- ----------------------------\n";
                echo "-- Records of `{$cleanT}`\n";
                echo "-- ----------------------------\n";
                foreach ($dataRows as $row) {
                    $cols = array_map(function($c) { return "`" . str_replace('`', '', $c) . "`"; }, array_keys($row));
                    $vals = array_map(function($v) use ($dbWrap) { return db_escape_val($dbWrap, $v); }, array_values($row));
                    echo "INSERT INTO `{$cleanT}` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n";
                }
                echo "\n";
            }
        }
        echo "SET FOREIGN_KEY_CHECKS = 1;\n";
    } catch (Throwable $e) {
        echo "-- Error exporting SQL: " . $e->getMessage();
    }
    exit;
}

// Xử lý Tải xuống & Xem trực tiếp file (GET)
if (isset($_GET['download']) || isset($_GET['preview'])) {
    $rel = $_GET['download'] ?? $_GET['preview'];
    $target = resolve_safe_path($rel);
    if (!$target || !is_file($target)) {
        http_response_code(404);
        exit('File not found');
    }
    $mime = function_exists('mime_content_type') ? @mime_content_type($target) : 'application/octet-stream';
    header('Content-Type: ' . ($mime ?: 'application/octet-stream'));
    header('Content-Length: ' . @filesize($target));
    if (isset($_GET['download'])) {
        header('Content-Disposition: attachment; filename="' . basename($target) . '"');
    }
    readfile($target);
    exit;
}

// Xử lý API AJAX
$action = $_GET['api'] ?? '';
$rawBody = @file_get_contents('php://input');
$jsonInput = $rawBody ? @json_decode($rawBody, true) : null;
$input = is_array($jsonInput) ? $jsonInput : $_POST;

try {
    switch ($action) {
        case 'ping':
            safe_json_out(['status' => 'ok', 'ts' => microtime(true)]);
            break;

        case 'clear_logs':
            clear_login_logs();
            record_login_log(true); // Giữ lại phiên hiện tại
            safe_json_out(['status' => 'ok', 'logs' => get_login_logs()]);
            break;

        case 'list':
            $rel = clean_rel_path($_GET['path'] ?? '');
            $dir = resolve_safe_path($rel);
            if (!$dir || !is_dir($dir)) throw new Exception("Thư mục không tồn tại.");

            $scan = @scandir($dir);
            if (!is_array($scan)) $scan = [];
            $items = [];
            $directFilesSize = 0;
            foreach ($scan as $name) {
                if ($name === '.' || $name === '..') continue;
                if (strpos($name, '.dongm_part_') === 0) continue;

                $full = $dir . DIRECTORY_SEPARATOR . $name;
                // Ẩn thư mục /dongm khỏi danh sách ngoài gốc để tránh xóa nhầm bộ công cụ
                if ($PROTECT_SELF_DIR && @realpath($full) === @realpath(__DIR__)) continue;

                $isDir = @is_dir($full);
                $fSize = $isDir ? 0 : (@filesize($full) ?: 0);
                $directFilesSize += $fSize;
                $ext = $isDir ? '' : strtolower(pathinfo($name, PATHINFO_EXTENSION));
                $items[] = [
                    'name'  => $name,
                    'rel'   => $rel ? ($rel . '/' . $name) : $name,
                    'isDir' => $isDir,
                    'size'  => $fSize,
                    'mtime' => @filemtime($full) ?: 0,
                    'perms' => get_perms_octal($full),
                    'ext'   => $ext
                ];
            }

            $mysqlState = null;
            if (!empty($_SESSION['dongm_db'])) {
                try {
                    $mysqlState = fetch_mysql_session_state($_SESSION['dongm_db']);
                } catch (Throwable $dbEx) {
                    unset($_SESSION['dongm_db']);
                }
            }

            safe_json_out([
                'status'          => 'ok',
                'path'            => $rel,
                'items'           => $items,
                'directFilesSize' => $directFilesSize,
                'server'          => get_server_specs($dir),
                'login_logs'      => get_login_logs(),
                'mysql_state'     => $mysqlState
            ]);
            break;

        case 'dir_size':
            $rel = clean_rel_path($input['path'] ?? '');
            $dir = resolve_safe_path($rel);
            if (!$dir || !is_dir($dir)) throw new Exception("Thư mục không hợp lệ.");
            $deepSize = get_dir_deep_size($dir);
            safe_json_out(['status' => 'ok', 'deepSize' => $deepSize]);
            break;

        case 'read':
            $target = resolve_safe_path($input['path'] ?? '');
            if (!$target || !is_file($target)) throw new Exception("Không tìm thấy tệp tin.");
            if (@filesize($target) > 8 * 1024 * 1024) throw new Exception("Tệp quá lớn (> 8MB), vui lòng tải về máy để chỉnh sửa.");
            $content = @file_get_contents($target);
            safe_json_out(['status' => 'ok', 'content' => (string)$content, 'mtime' => @filemtime($target) ?: 0]);
            break;

        case 'save':
            $target = resolve_safe_path($input['path'] ?? '');
            if (!$target) throw new Exception("Đường dẫn không hợp lệ.");
            if (@file_put_contents($target, $input['content'] ?? '') === false) {
                throw new Exception("Không thể ghi tệp tin. Hãy kiểm tra quyền CHMOD.");
            }
            safe_json_out(['status' => 'ok', 'mtime' => @filemtime($target) ?: time()]);
            break;

        case 'mkdir':
            $base = resolve_safe_path($input['path'] ?? '');
            $name = trim(basename($input['name'] ?? ''));
            if (!$base || !$name) throw new Exception("Tên thư mục không hợp lệ.");
            $newDir = $base . DIRECTORY_SEPARATOR . $name;
            if (file_exists($newDir)) throw new Exception("Trùng tên: Thư mục hoặc tệp '{$name}' đã tồn tại!");
            if (!@mkdir($newDir, 0755, true)) throw new Exception("Không thể tạo thư mục.");
            safe_json_out(['status' => 'ok']);
            break;

        case 'mkfile':
            $base = resolve_safe_path($input['path'] ?? '');
            $name = trim(basename($input['name'] ?? ''));
            $overwrite = !empty($input['overwrite']);
            if (!$base || !$name) throw new Exception("Tên tệp không hợp lệ.");
            $newFile = $base . DIRECTORY_SEPARATOR . $name;
            if (file_exists($newFile) && !$overwrite) {
                throw new Exception("Trùng tên: Tệp '{$name}' đã tồn tại trong thư mục này!");
            }
            if (@file_put_contents($newFile, '') === false) throw new Exception("Không thể tạo tệp tin.");
            safe_json_out(['status' => 'ok']);
            break;

        case 'rename':
            $old = resolve_safe_path($input['path'] ?? '');
            $newName = trim(basename($input['newName'] ?? ''));
            if (!$old || !file_exists($old) || !$newName) throw new Exception("Dữ liệu không hợp lệ.");
            if (is_protected_dongm_dir($old)) throw new Exception("Không thể đổi tên thư mục hệ thống DONGM.");
            $newPath = dirname($old) . DIRECTORY_SEPARATOR . $newName;
            if (@realpath($old) !== @realpath($newPath) && file_exists($newPath)) {
                throw new Exception("Trùng tên: '{$newName}' đã tồn tại trong thư mục!");
            }
            if (!@rename($old, $newPath)) throw new Exception("Đổi tên thất bại.");
            safe_json_out(['status' => 'ok']);
            break;

        case 'chmod':
            $target = resolve_safe_path($input['path'] ?? '');
            $perms = $input['perms'] ?? '0644';
            if (!$target || !file_exists($target)) throw new Exception("Tệp không tồn tại.");
            if (!@chmod($target, octdec($perms))) throw new Exception("Không thể đổi quyền CHMOD.");
            safe_json_out(['status' => 'ok']);
            break;

        case 'paste':
            $destDir = resolve_safe_path($input['dest'] ?? '');
            $paths   = $input['paths'] ?? [];
            $mode    = $input['mode'] ?? 'copy';
            if (!$destDir || !is_dir($destDir)) throw new Exception("Thư mục đích không hợp lệ.");
            $done = 0;
            foreach ($paths as $p) {
                $src = resolve_safe_path($p);
                if (!$src || !file_exists($src) || is_protected_dongm_dir($src)) continue;
                $baseName = basename($src);
                $target = $destDir . DIRECTORY_SEPARATOR . $baseName;
                if (@realpath($src) === @realpath($target)) continue;
                if (file_exists($target)) {
                    $target = get_unique_dest_path($destDir, $baseName);
                }
                if ($mode === 'cut') {
                    if (@rename($src, $target)) $done++;
                } else {
                    if (rcopy($src, $target)) $done++;
                }
            }
            safe_json_out(['status' => 'ok', 'count' => $done]);
            break;

        case 'delete':
            $paths = $input['paths'] ?? [];
            if (empty($paths)) throw new Exception("Chưa chọn mục nào.");
            foreach ($paths as $p) {
                $target = resolve_safe_path($p);
                if ($target && $target !== @realpath($ROOT_DIR) && !is_protected_dongm_dir($target)) {
                    rrmdir($target);
                }
            }
            safe_json_out(['status' => 'ok']);
            break;

        case 'upload_chunk':
            $base = resolve_safe_path($_POST['path'] ?? '');
            if (!$base || !is_dir($base)) throw new Exception("Thư mục đích không hợp lệ.");

            $fileName    = trim(basename($_POST['file_name'] ?? ''));
            $uploadId    = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['upload_id'] ?? '');
            $chunkIndex  = (int)($_POST['chunk_index'] ?? 0);
            $totalChunks = (int)($_POST['total_chunks'] ?? 1);
            $dupMode     = $_POST['dup_mode'] ?? 'overwrite';

            if ($fileName === '' || $uploadId === '') {
                throw new Exception("Thông tin định danh mảnh tải lên không hợp lệ.");
            }
            if (empty($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
                $errCode = $_FILES['chunk']['error'] ?? -1;
                throw new Exception("Lỗi truyền mảnh dữ liệu #{$chunkIndex} (Mã lỗi PHP: {$errCode}).");
            }

            $tempPartFile = $base . DIRECTORY_SEPARATOR . '.dongm_part_' . $uploadId;

            if ($chunkIndex === 0 && file_exists($tempPartFile)) {
                @unlink($tempPartFile);
            }

            $in = @fopen($_FILES['chunk']['tmp_name'], 'rb');
            if (!$in) throw new Exception("Không thể đọc dữ liệu mảnh tạm.");

            $out = @fopen($tempPartFile, $chunkIndex === 0 ? 'wb' : 'ab');
            if (!$out) {
                fclose($in);
                throw new Exception("Không thể ghi mảnh tệp vào thư mục đích (Kiểm tra quyền CHMOD).");
            }

            stream_copy_to_stream($in, $out);
            fclose($in);
            fclose($out);
            @unlink($_FILES['chunk']['tmp_name']);

            if ($chunkIndex + 1 >= $totalChunks) {
                $finalDest = ($dupMode === 'rename')
                    ? get_unique_dest_path($base, $fileName)
                    : ($base . DIRECTORY_SEPARATOR . $fileName);

                if ($dupMode === 'overwrite' && file_exists($finalDest)) {
                    @unlink($finalDest);
                }
                if (!@rename($tempPartFile, $finalDest)) {
                    @unlink($tempPartFile);
                    throw new Exception("Không thể ghép nối hoàn tất tệp '{$fileName}'.");
                }
                safe_json_out([
                    'status'    => 'ok',
                    'completed' => true,
                    'savedName' => basename($finalDest)
                ]);
            } else {
                safe_json_out([
                    'status'     => 'ok',
                    'completed'  => false,
                    'chunkIndex' => $chunkIndex
                ]);
            }
            break;

        case 'upload_cancel':
            $base     = resolve_safe_path($input['path'] ?? '');
            $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', $input['upload_id'] ?? '');
            if ($base && $uploadId) {
                $tempPartFile = $base . DIRECTORY_SEPARATOR . '.dongm_part_' . $uploadId;
                if (file_exists($tempPartFile)) @unlink($tempPartFile);
            }
            safe_json_out(['status' => 'ok']);
            break;

        case 'zip':
            if (!class_exists('ZipArchive')) throw new Exception("Hosting chưa bật tiện ích ZipArchive.");
            $base = resolve_safe_path($input['path'] ?? '');
            $paths = $input['paths'] ?? [];
            if (empty($paths)) throw new Exception("Chưa chọn mục nào để nén.");

            $defaultName = 'backup_' . date('H-i-s_d-m-Y') . '.zip';
            $zipName = trim(basename($input['zipName'] ?? $defaultName));
            if ($zipName === '') $zipName = $defaultName;
            if (substr(strtolower($zipName), -4) !== '.zip') $zipName .= '.zip';

            $level = (int)($input['level'] ?? 6);
            $overwrite = !empty($input['overwrite']);
            $zipTarget = $base . DIRECTORY_SEPARATOR . $zipName;

            if (file_exists($zipTarget) && !$overwrite) {
                throw new Exception("Trùng tên: File nén '{$zipName}' đã tồn tại!");
            }

            $zip = new ZipArchive();
            if ($zip->open($zipTarget, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
                throw new Exception("Không thể khởi tạo file ZIP.");
            }

            $addedCount = 0;
            $compMethod = ($level === 0) ? ZipArchive::CM_STORE : ZipArchive::CM_DEFLATE;

            foreach ($paths as $p) {
                $itemPath = resolve_safe_path($p);
                if (!$itemPath || !file_exists($itemPath)) continue;
                if (@realpath($itemPath) === @realpath($zipTarget)) continue;

                if (is_dir($itemPath)) {
                    $rootFolder = basename($itemPath);
                    $zip->addEmptyDir($rootFolder);
                    $files = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($itemPath, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::SELF_FIRST
                    );
                    $parentLen = strlen(dirname($itemPath)) + 1;
                    foreach ($files as $file) {
                        $real = $file->getRealPath();
                        if ($real === @realpath($zipTarget)) continue;
                        $local = str_replace('\\', '/', substr($real, $parentLen));
                        if ($file->isDir()) {
                            $zip->addEmptyDir($local);
                        } else {
                            if ($zip->addFile($real, $local)) {
                                if (method_exists($zip, 'setCompressionName')) {
                                    @$zip->setCompressionName($local, $compMethod, $level);
                                }
                                $addedCount++;
                            }
                        }
                    }
                } else {
                    $local = basename($itemPath);
                    if ($zip->addFile($itemPath, $local)) {
                        if (method_exists($zip, 'setCompressionName')) {
                            @$zip->setCompressionName($local, $compMethod, $level);
                        }
                        $addedCount++;
                    }
                }
            }
            $zip->close();
            $finalSize = @filesize($zipTarget) ?: 0;
            safe_json_out([
                'status'     => 'ok',
                'zipName'    => $zipName,
                'addedFiles' => $addedCount,
                'zipSize'    => $finalSize
            ]);
            break;

        case 'zip_preview':
            if (!class_exists('ZipArchive')) throw new Exception("Hosting chưa bật tiện ích ZipArchive.");
            $target = resolve_safe_path($input['path'] ?? '');
            if (!$target || !is_file($target)) throw new Exception("Không tìm thấy file ZIP.");
            $zip = new ZipArchive();
            if ($zip->open($target) !== TRUE) throw new Exception("Không thể đọc cấu trúc file ZIP này.");
            $entries = [];
            $totalSize = 0;
            $totalComp = 0;
            $limit = min($zip->numFiles, 500);
            for ($i = 0; $i < $limit; $i++) {
                $st = $zip->statIndex($i);
                $isDir = substr($st['name'], -1) === '/';
                $entries[] = [
                    'name'  => $st['name'],
                    'size'  => $st['size'],
                    'comp'  => $st['comp_size'],
                    'mtime' => $st['mtime'],
                    'isDir' => $isDir
                ];
                $totalSize += $st['size'];
                $totalComp += $st['comp_size'];
            }
            $numFiles = $zip->numFiles;
            $zip->close();
            safe_json_out([
                'status'    => 'ok',
                'totalCount'=> $numFiles,
                'totalSize' => $totalSize,
                'totalComp' => $totalComp,
                'entries'   => $entries
            ]);
            break;

        case 'unzip':
            if (!class_exists('ZipArchive')) throw new Exception("Hosting chưa bật tiện ích ZipArchive.");
            $target = resolve_safe_path($input['path'] ?? '');
            if (!$target || !is_file($target)) throw new Exception("Không tìm thấy file ZIP.");
            $zip = new ZipArchive();
            if ($zip->open($target) === TRUE) {
                $zip->extractTo(dirname($target));
                $zip->close();
                safe_json_out(['status' => 'ok']);
            } else {
                throw new Exception("Giải nén thất bại.");
            }
            break;

        case 'mysql_connect':
            $cfg = [
                'host' => trim($input['host'] ?? 'localhost'),
                'port' => (int)($input['port'] ?? 3306),
                'user' => trim($input['user'] ?? ''),
                'pass' => $input['pass'] ?? '',
                'db'   => trim($input['db'] ?? '')
            ];
            if ($cfg['pass'] === '' && !empty($_SESSION['dongm_db']['pass']) && $_SESSION['dongm_db']['user'] === $cfg['user']) {
                $cfg['pass'] = $_SESSION['dongm_db']['pass'];
            }
            $_SESSION['dongm_db'] = $cfg;
            $state = fetch_mysql_session_state($cfg);
            safe_json_out(array_merge(['status' => 'ok'], $state));
            break;

        case 'mysql_switch_db':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $_SESSION['dongm_db']['db'] = trim($input['db'] ?? '');
            $state = fetch_mysql_session_state($_SESSION['dongm_db']);
            safe_json_out(array_merge(['status' => 'ok'], $state));
            break;

        case 'mysql_query':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Phiên kết nối MySQL đã hết hạn. Vui lòng kết nối lại.");
            $sql = trim($input['sql'] ?? '');
            if ($sql === '') throw new Exception("Câu lệnh SQL không được để trống.");
            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $result = run_db_query($dbWrap, $sql);
            safe_json_out(['status' => 'ok', 'result' => $result]);
            break;

        case 'mysql_table_structure':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $table = str_replace('`', '', trim($input['table'] ?? ''));
            if (!$table) throw new Exception("Chưa chọn bảng.");
            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $cols = run_simple_Fetch($dbWrap, "SHOW FULL COLUMNS FROM `{$table}`");
            $idxs = run_simple_Fetch($dbWrap, "SHOW INDEX FROM `{$table}`");
            safe_json_out(['status' => 'ok', 'table' => $table, 'columns' => $cols, 'indexes' => $idxs]);
            break;

        case 'mysql_update_cell':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $table = str_replace('`', '', trim($input['table'] ?? ''));
            $pkCol = str_replace('`', '', trim($input['pk_col'] ?? ''));
            $pkVal = $input['pk_val'] ?? null;
            $col   = str_replace('`', '', trim($input['column'] ?? ''));
            $val   = $input['value'] ?? null;

            if (!$table || !$pkCol || $pkVal === null || !$col) {
                throw new Exception("Thiếu khóa chính (Primary Key) hoặc tên cột để cập nhật trực tiếp.");
            }
            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $escapedVal = db_escape_val($dbWrap, $val);
            $escapedPk  = db_escape_val($dbWrap, $pkVal);
            $sql = "UPDATE `{$table}` SET `{$col}` = {$escapedVal} WHERE `{$pkCol}` = {$escapedPk} LIMIT 1";
            $res = run_db_query($dbWrap, $sql);
            safe_json_out(['status' => 'ok', 'sql' => $sql, 'affected' => $res['affected'] ?? 1]);
            break;

        case 'mysql_delete_row':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $table = str_replace('`', '', trim($input['table'] ?? ''));
            $pkCol = str_replace('`', '', trim($input['pk_col'] ?? ''));
            $pkVal = $input['pk_val'] ?? null;
            if (!$table || !$pkCol || $pkVal === null) throw new Exception("Thiếu khóa chính để xóa dòng.");
            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $escapedPk = db_escape_val($dbWrap, $pkVal);
            $sql = "DELETE FROM `{$table}` WHERE `{$pkCol}` = {$escapedPk} LIMIT 1";
            $res = run_db_query($dbWrap, $sql);
            safe_json_out(['status' => 'ok', 'sql' => $sql]);
            break;

        case 'mysql_insert_row':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $table = str_replace('`', '', trim($input['table'] ?? ''));
            $data  = $input['data'] ?? [];
            if (!$table || empty($data)) throw new Exception("Dữ liệu thêm mới không hợp lệ.");
            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $cols = [];
            $vals = [];
            foreach ($data as $k => $v) {
                if ($v === '' || $v === null) continue;
                $cols[] = "`" . str_replace('`', '', $k) . "`";
                $vals[] = db_escape_val($dbWrap, $v);
            }
            if (empty($cols)) throw new Exception("Vui lòng nhập ít nhất 1 trường dữ liệu.");
            $sql = "INSERT INTO `{$table}` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
            $res = run_db_query($dbWrap, $sql);
            safe_json_out(['status' => 'ok', 'sql' => $sql]);
            break;

        case 'mysql_import':
            if (empty($_SESSION['dongm_db'])) throw new Exception("Chưa kết nối MySQL.");
            $sqlContent = '';
            if (!empty($_FILES['sql_file']) && $_FILES['sql_file']['error'] === UPLOAD_ERR_OK) {
                $sqlContent = file_get_contents($_FILES['sql_file']['tmp_name']);
            } elseif (!empty($_POST['sql_text'])) {
                $sqlContent = $_POST['sql_text'];
            } elseif (!empty($input['sql_text'])) {
                $sqlContent = $input['sql_text'];
            }
            if (trim($sqlContent) === '') throw new Exception("Không có nội dung SQL để Import.");

            $dbWrap = get_db_connection($_SESSION['dongm_db']);
            $executed = 0;
            if ($dbWrap['type'] === 'mysqli') {
                $conn = $dbWrap['conn'];
                if (!$conn->multi_query($sqlContent)) {
                    throw new Exception("Lỗi Import SQL: " . $conn->error);
                }
                do {
                    $executed++;
                    if ($res = $conn->store_result()) $res->free();
                } while ($conn->more_results() && $conn->next_result());
                if ($conn->errno) throw new Exception("Lỗi tại câu lệnh thứ {$executed}: " . $conn->error);
            } else {
                $dbWrap['conn']->exec($sqlContent);
                $executed = 1;
            }
            safe_json_out(['status' => 'ok', 'executed' => $executed]);
            break;

        case 'mysql_disconnect':
            unset($_SESSION['dongm_db']);
            safe_json_out(['status' => 'ok']);
            break;

        default:
            throw new Exception("Yêu cầu API không hợp lệ.");
    }
} catch (Throwable $e) {
    safe_json_out(['status' => 'error', 'message' => $e->getMessage()]);
}