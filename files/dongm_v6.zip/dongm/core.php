<?php
/**
 * DONGM Workspace v6.0 - Module 2: Core Functions & Login History
 * Crafted by Đặng Minh Đông
 */
if (!defined('DONGM_LOADED')) define('DONGM_LOADED', true);

function safe_json_out($data) {
    if (ob_get_length()) @ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $out = json_encode($data, $flags);
    if ($out === false) {
        $out = json_encode(['status' => 'error', 'message' => 'Lỗi mã hóa JSON: ' . json_last_error_msg()]);
    }
    echo $out;
    exit;
}

// ================= HỆ THỐNG LỊCH SỬ ĐĂNG NHẬP =================
function get_client_real_ip() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
}

function parse_short_user_agent($ua) {
    $browser = 'Browser';
    if (stripos($ua, 'Edg/') !== false) $browser = 'Edge';
    elseif (stripos($ua, 'OPR/') !== false || stripos($ua, 'Opera') !== false) $browser = 'Opera';
    elseif (stripos($ua, 'Chrome/') !== false) $browser = 'Chrome';
    elseif (stripos($ua, 'Firefox/') !== false) $browser = 'Firefox';
    elseif (stripos($ua, 'Safari/') !== false) $browser = 'Safari';

    $os = 'OS';
    if (stripos($ua, 'Windows') !== false) $os = 'Windows';
    elseif (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPad') !== false) $os = 'iOS';
    elseif (stripos($ua, 'Android') !== false) $os = 'Android';
    elseif (stripos($ua, 'Mac OS X') !== false || stripos($ua, 'Macintosh') !== false) $os = 'macOS';
    elseif (stripos($ua, 'Linux') !== false) $os = 'Linux';

    return $browser . ' • ' . $os;
}

function record_login_log($success = true) {
    global $LOG_FILE;
    $logs = get_login_logs();
    $entry = [
        'ip'      => get_client_real_ip(),
        'device'  => parse_short_user_agent($_SERVER['HTTP_USER_AGENT'] ?? ''),
        'time'    => date('H:i:s d/m/Y'),
        'success' => (bool)$success
    ];
    array_unshift($logs, $entry);
    $logs = array_slice($logs, 0, 25); // Giữ tối đa 25 lần đăng nhập gần nhất
    @file_put_contents($LOG_FILE, json_encode($logs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function get_login_logs() {
    global $LOG_FILE;
    if (!file_exists($LOG_FILE)) return [];
    $raw = @file_get_contents($LOG_FILE);
    $data = $raw ? @json_decode($raw, true) : [];
    return is_array($data) ? $data : [];
}

function clear_login_logs() {
    global $LOG_FILE;
    @file_put_contents($LOG_FILE, json_encode([]));
}

// ================= HÀM HỖ TRỢ FILE & HỆ THỐNG =================
function parse_ini_bytes($val) {
    $val = trim((string)$val);
    if ($val === '') return 0;
    $last = strtolower(substr($val, -1));
    $num = (float)$val;
    switch ($last) {
        case 'g': $num *= 1073741824; break;
        case 'm': $num *= 1048576; break;
        case 'k': $num *= 1024; break;
    }
    return (int)$num;
}

function get_optimal_chunk_size() {
    $u = parse_ini_bytes(@ini_get('upload_max_filesize'));
    $p = parse_ini_bytes(@ini_get('post_max_size'));
    $limit = ($u > 0 && $p > 0) ? min($u, $p) : ($u > 0 ? $u : ($p > 0 ? $p : 8 * 1048576));
    $safe = (int)floor($limit * 0.5);
    return max(256 * 1024, min(2 * 1048576, $safe));
}

function clean_rel_path($path) {
    $path = str_replace(['\\', '//'], '/', (string)$path);
    $parts = array_filter(explode('/', $path), function($p) {
        return $p !== '' && $p !== '.' && $p !== '..';
    });
    return implode('/', $parts);
}

function resolve_safe_path($rel) {
    global $ROOT_DIR;
    $rel = clean_rel_path($rel);
    $full = $ROOT_DIR . ($rel ? DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel) : '');
    $realRoot = @realpath($ROOT_DIR);
    if (!$realRoot) $realRoot = $ROOT_DIR;
    $realFull = @realpath($full);
    if ($realFull !== false) {
        if (strpos($realFull, $realRoot) !== 0) return false;
        return $realFull;
    }
    $parent = @realpath(dirname($full));
    if ($parent !== false && strpos($parent, $realRoot) === 0) {
        return $parent . DIRECTORY_SEPARATOR . basename($full);
    }
    return false;
}

function is_protected_dongm_dir($targetPath) {
    global $PROTECT_SELF_DIR;
    if (!$PROTECT_SELF_DIR) return false;
    $realSelf = @realpath(__DIR__);
    $realTarget = @realpath($targetPath);
    if ($realSelf && $realTarget && strpos($realTarget, $realSelf) === 0) {
        return true;
    }
    return false;
}

function rrmdir($dir) {
    if (is_protected_dongm_dir($dir)) return false;
    if (!is_dir($dir)) return @unlink($dir);
    $items = @scandir($dir);
    if (is_array($items)) {
        foreach (array_diff($items, ['.', '..']) as $item) {
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            is_dir($path) ? rrmdir($path) : @unlink($path);
        }
    }
    return @rmdir($dir);
}

function rcopy($src, $dst) {
    if (is_dir($src)) {
        if (!is_dir($dst)) @mkdir($dst, 0755, true);
        $items = @scandir($src);
        if (is_array($items)) {
            foreach (array_diff($items, ['.', '..']) as $item) {
                rcopy($src . DIRECTORY_SEPARATOR . $item, $dst . DIRECTORY_SEPARATOR . $item);
            }
        }
        return true;
    }
    return @copy($src, $dst);
}

function get_dir_deep_size($dir) {
    $size = 0;
    try {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if ($file->isFile()) $size += @$file->getSize();
        }
    } catch (Throwable $t) {}
    return $size;
}

function get_unique_dest_path($dir, $filename) {
    $info = pathinfo($filename);
    $base = $info['filename'] ?? 'file';
    $ext  = isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : '';
    $candidate = $filename;
    $counter = 1;
    while (file_exists($dir . DIRECTORY_SEPARATOR . $candidate)) {
        $candidate = $base . " ({$counter})" . $ext;
        $counter++;
    }
    return $dir . DIRECTORY_SEPARATOR . $candidate;
}

function get_perms_octal($path) {
    $p = @fileperms($path);
    return $p ? substr(sprintf('%o', $p), -4) : '0644';
}

function get_server_specs($dir) {
    $free  = function_exists('disk_free_space') ? (@disk_free_space($dir) ?: 0) : 0;
    $total = function_exists('disk_total_space') ? (@disk_total_space($dir) ?: 0) : 0;
    $used  = max(0, $total - $free);
    $osStr = function_exists('php_uname') ? (@php_uname('s') . ' ' . @php_uname('r')) : PHP_OS;
    $srvIp = $_SERVER['SERVER_ADDR'] ?? '';
    if (!$srvIp && function_exists('gethostname') && function_exists('gethostbyname')) {
        $srvIp = @gethostbyname(@gethostname());
    }
    return [
        'php_version' => PHP_VERSION,
        'os'          => trim($osStr) ?: 'Linux',
        'software'    => $_SERVER['SERVER_SOFTWARE'] ?? 'Web Server',
        'server_ip'   => $srvIp ?: '127.0.0.1',
        'client_ip'   => get_client_real_ip(),
        'memory_limit'=> @ini_get('memory_limit') ?: '128M',
        'upload_ini'  => @ini_get('upload_max_filesize') ?: '20M',
        'post_ini'    => @ini_get('post_max_size') ?: '20M',
        'chunk_size'  => get_optimal_chunk_size(),
        'disk_free'   => $free,
        'disk_total'  => $total,
        'disk_used'   => $used,
        'ext_zip'     => class_exists('ZipArchive'),
        'ext_curl'    => function_exists('curl_version'),
        'ext_mysqli'  => extension_loaded('mysqli') || extension_loaded('pdo_mysql'),
        'ext_mb'      => extension_loaded('mbstring'),
    ];
}

// ================= HÀM HỖ TRỢ MYSQL =================
function get_db_connection($cfg) {
    $host = $cfg['host'] ?? 'localhost';
    $user = $cfg['user'] ?? '';
    $pass = $cfg['pass'] ?? '';
    $db   = $cfg['db']   ?? '';
    $port = (int)($cfg['port'] ?? 3306);

    if (class_exists('mysqli')) {
        if (function_exists('mysqli_report')) @mysqli_report(MYSQLI_REPORT_OFF);
        $conn = @new mysqli($host, $user, $pass, $db, $port);
        if ($conn->connect_errno) {
            throw new Exception("Kết nối MySQL thất bại: " . $conn->connect_error);
        }
        @$conn->set_charset("utf8mb4");
        return ['type' => 'mysqli', 'conn' => $conn];
    } elseif (extension_loaded('pdo_mysql')) {
        $dsn = "mysql:host={$host};port={$port};" . ($db ? "dbname={$db};" : "") . "charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        return ['type' => 'pdo', 'conn' => $pdo];
    }
    throw new Exception("Server không hỗ trợ tiện ích MySQLi hoặc PDO_MySQL.");
}

function db_escape_val($dbWrap, $val) {
    if ($val === null) return 'NULL';
    if ($dbWrap['type'] === 'mysqli') {
        return "'" . $dbWrap['conn']->real_escape_string((string)$val) . "'";
    } else {
        return $dbWrap['conn']->quote((string)$val);
    }
}

function run_simple_Fetch($dbWrap, $sql) {
    if ($dbWrap['type'] === 'mysqli') {
        $r = @$dbWrap['conn']->query($sql);
        if (!$r || $r === true) return [];
        $out = [];
        while ($row = $r->fetch_assoc()) $out[] = $row;
        return $out;
    } else {
        $s = @$dbWrap['conn']->query($sql);
        return $s ? $s->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}

function run_db_query($dbWrap, $sql) {
    $t0 = microtime(true);
    $tableName = '';
    $primaryKey = '';

    if (preg_match('/^\s*SELECT\s+.*?\s+FROM\s+`?([a-zA-Z0-9_]+)`?/is', $sql, $m)) {
        $tableName = $m[1];
    }

    if ($dbWrap['type'] === 'mysqli') {
        $conn = $dbWrap['conn'];
        $res = @$conn->query($sql);
        if ($res === false) throw new Exception($conn->error);
        $time = round((microtime(true) - $t0) * 1000, 2);
        if ($res === true) {
            return ['is_select' => false, 'affected' => $conn->affected_rows, 'time_ms' => $time];
        }
        $rows = [];
        $fields = [];
        while ($f = $res->fetch_field()) {
            $fields[] = $f->name;
            if (($f->flags & 2) && !$primaryKey) {
                $primaryKey = $f->name;
            }
        }
        while ($r = $res->fetch_assoc()) $rows[] = $r;
    } else {
        $pdo = $dbWrap['conn'];
        $stmt = $pdo->query($sql);
        $time = round((microtime(true) - $t0) * 1000, 2);
        $colCount = $stmt->columnCount();
        if ($colCount === 0) {
            return ['is_select' => false, 'affected' => $stmt->rowCount(), 'time_ms' => $time];
        }
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $fields = [];
        for ($i = 0; $i < $colCount; $i++) {
            $meta = $stmt->getColumnMeta($i);
            $fields[] = $meta['name'];
            if (in_array('primary_key', $meta['flags'] ?? []) && !$primaryKey) {
                $primaryKey = $meta['name'];
            }
        }
    }

    if ($tableName && !$primaryKey) {
        try {
            $pkCheck = run_simple_Fetch($dbWrap, "SHOW KEYS FROM `" . str_replace('`', '', $tableName) . "` WHERE Key_name = 'PRIMARY'");
            if (!empty($pkCheck[0]['Column_name'])) {
                $primaryKey = $pkCheck[0]['Column_name'];
            }
        } catch (Throwable $ex) {}
    }

    return [
        'is_select'   => true,
        'columns'     => $fields,
        'rows'        => $rows,
        'count'       => count($rows),
        'time_ms'     => $time,
        'table'       => $tableName,
        'primary_key' => $primaryKey
    ];
}

function fetch_mysql_session_state($cfg) {
    $dbWrap = get_db_connection($cfg);
    $dbsRes = run_db_query($dbWrap, "SHOW DATABASES");
    $databases = array_map(function($r) { return reset($r); }, $dbsRes['rows']);

    if (empty($cfg['db']) && !empty($databases)) {
        foreach ($databases as $d) {
            if (!in_array($d, ['information_schema', 'performance_schema', 'mysql', 'sys'])) {
                $cfg['db'] = $d;
                $_SESSION['dongm_db']['db'] = $d;
                break;
            }
        }
    }

    $tables = [];
    if (!empty($cfg['db'])) {
        $dbWrap = get_db_connection($cfg);
        $tblRes = run_db_query($dbWrap, "SHOW TABLE STATUS FROM `" . str_replace('`', '', $cfg['db']) . "`");
        foreach ($tblRes['rows'] as $row) {
            $tables[] = [
                'name'      => $row['Name'],
                'rows'      => $row['Rows'] ?? 0,
                'engine'    => $row['Engine'] ?? '',
                'collation' => $row['Collation'] ?? '',
                'size'      => ($row['Data_length'] ?? 0) + ($row['Index_length'] ?? 0)
            ];
        }
    }

    return [
        'host'      => $cfg['host'],
        'port'      => $cfg['port'],
        'user'      => $cfg['user'],
        'currentDb' => $cfg['db'],
        'databases' => $databases,
        'tables'    => $tables
    ];
}