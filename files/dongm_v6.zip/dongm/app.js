/**
 * DONGM Workspace v6.0 - Module 6: Frontend SPA Engine
 * Crafted by Đặng Minh Đông
 */
let currentPath = '';
let currentItems = [];
let selectedPaths = new Set();
let clipboardState = { mode: '', paths: [] };
let sortField = 'name';
let sortAsc = true;

let pendingZipTargets = [];
let pendingUploadFiles = null;
let uploadCancelRequested = false;
let currentUploadId = '';
let dynamicChunkSize = 2097152; // 2MB mặc định
let currentActionModal = { type: '', targetRel: '', oldName: '' };

let aceInstance = null;
let editorFontSize = 13;
let editorWrap = true;
let editingPath = '';
let fileContentCache = new Map();

let soundEnabled = localStorage.getItem('dongm_sound') !== 'off';
let audioCtx = null;

let currentSqlDb = '';
let currentSqlTable = '';
let currentSqlColumns = [];
let currentSqlPk = '';
let currentSqlRows = [];
let currentTablesList = [];
let mysqlSessionRestored = false;

let loadingTimer = null;
let activeRequests = 0;

const MAX_UPLOAD_BYTES = 500 * 1024 * 1024;
const EDITABLE_EXT = ['php','html','htm','css','js','ts','json','xml','sql','md','txt','htaccess','env','ini','yml','yaml','sh','py','vue','astro','conf','log'];
const IMAGE_EXT    = ['jpg','jpeg','png','gif','webp','svg','ico','bmp'];

function isDuplicateName(name, ignoreName = '') {
    const target = name.trim().toLowerCase();
    const ignore = ignoreName.trim().toLowerCase();
    if (!target) return false;
    return currentItems.some(item => {
        const n = item.name.toLowerCase();
        return n === target && n !== ignore;
    });
}

// ================= KHỞI TẠO SỚM ACE EDITOR =================
function preInitAceEditor() {
    if (aceInstance || typeof ace === 'undefined') return;
    try {
        aceInstance = ace.edit("aceEditor");
        const isDark = document.documentElement.classList.contains('dark');
        aceInstance.setTheme(isDark ? "ace/theme/one_dark" : "ace/theme/chrome");
        aceInstance.setOptions({
            fontSize: editorFontSize + "px",
            fontFamily: "'JetBrains Mono', monospace",
            showPrintMargin: false,
            wrap: true,
            indentedSoftWrap: true,
            scrollPastEnd: 0.3,
            useWorker: false
        });
        aceInstance.getSession().setUseWrapMode(true);
        aceInstance.commands.addCommand({
            name: 'save',
            bindKey: { win: 'Ctrl-S', mac: 'Command-S' },
            exec: () => saveFileContent()
        });
        aceInstance.selection.on('changeCursor', () => {
            const pos = aceInstance.getCursorPosition();
            document.getElementById('editorCursorInfo').textContent = `Dòng ${pos.row + 1}, Cột ${pos.column + 1}`;
        });
        updateWrapBtnUI();
    } catch (e) {}
}

function applyEditorWrapState() {
    if (!aceInstance) return;
    aceInstance.getSession().setUseWrapMode(editorWrap);
    aceInstance.setOption("wrap", editorWrap);
    updateWrapBtnUI();
}

function updateWrapBtnUI() {
    const btn = document.getElementById('wrapBtn');
    if (!btn) return;
    if (editorWrap) {
        btn.textContent = 'Wrap: BẬT';
        btn.className = 'px-2.5 py-1 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-[11px] text-indigo-300 font-bold transition';
    } else {
        btn.textContent = 'Wrap: TẮT';
        btn.className = 'px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-[11px] text-slate-400 font-semibold transition';
    }
}

function toggleEditorWrap() {
    if (!aceInstance) return;
    editorWrap = !editorWrap;
    applyEditorWrapState();
}

function changeEditorFont(delta) {
    if (!aceInstance) return;
    editorFontSize = Math.min(22, Math.max(11, editorFontSize + delta));
    aceInstance.setFontSize(editorFontSize + "px");
}

// ================= THANH LOADING HIỆN ĐẠI =================
function startLoading(label = 'Đang xử lý...') {
    activeRequests++;
    const container = document.getElementById('topLoadingContainer');
    const bar       = document.getElementById('topLoadingBar');
    const pill      = document.getElementById('loadingPill');
    const pillText  = document.getElementById('loadingPillText');

    if (pillText) pillText.textContent = label;
    if (pill) { pill.classList.remove('hidden'); pill.classList.add('flex'); }
    document.querySelectorAll('.refreshIconCls').forEach(el => el.classList.add('fa-spin'));

    container.classList.remove('opacity-0');
    bar.style.width = '25%';

    clearInterval(loadingTimer);
    let progress = 25;
    loadingTimer = setInterval(() => {
        if (progress < 88) {
            progress += (90 - progress) * 0.18;
            bar.style.width = progress.toFixed(1) + '%';
        }
    }, 120);
}

function stopLoading() {
    activeRequests = Math.max(0, activeRequests - 1);
    if (activeRequests > 0) return;

    clearInterval(loadingTimer);
    const container = document.getElementById('topLoadingContainer');
    const bar       = document.getElementById('topLoadingBar');
    const pill      = document.getElementById('loadingPill');

    bar.style.width = '100%';
    document.querySelectorAll('.refreshIconCls').forEach(el => el.classList.remove('fa-spin'));

    setTimeout(() => {
        container.classList.add('opacity-0');
        if (pill) { pill.classList.add('hidden'); pill.classList.remove('flex'); }
        setTimeout(() => { bar.style.width = '0%'; }, 200);
    }, 220);
}

function generateTimestampZipName(prefix = 'backup') {
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${prefix}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}.zip`;
}

function switchRightTab(tab) {
    const btnInfo  = document.getElementById('tabBtnInfo');
    const btnSql   = document.getElementById('tabBtnSql');
    const paneInfo = document.getElementById('tabPaneInfo');
    const paneSql  = document.getElementById('tabPaneSql');

    const activeClass   = 'py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all bg-white dark:bg-slate-800 text-indigo-500 shadow-sm';
    const inactiveClass = 'py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all text-slate-500 hover:text-slate-800 dark:hover:text-slate-200';

    if (tab === 'sql') {
        btnInfo.className = inactiveClass;
        btnSql.className  = activeClass;
        paneInfo.classList.add('hidden');
        paneSql.classList.remove('hidden');
    } else {
        btnInfo.className = activeClass;
        btnSql.className  = inactiveClass;
        paneSql.classList.add('hidden');
        paneInfo.classList.remove('hidden');
    }
}

async function measurePing() {
    const el = document.getElementById('pingValue');
    const start = performance.now();
    try {
        await fetch('api.php?api=ping&t=' + Date.now(), { cache: 'no-store' });
        const ms = Math.max(1, Math.round(performance.now() - start));
        el.textContent = ms + ' ms';
        el.className = 'font-mono font-bold ' + (ms < 80 ? 'text-emerald-400' : (ms < 200 ? 'text-amber-400' : 'text-rose-400'));
    } catch (e) {
        el.textContent = 'Offline';
        el.className = 'font-mono font-bold text-rose-500';
    }
}

// ================= ÂM THANH THÔNG BÁO =================
function playSound(type = 'success') {
    if (!soundEnabled) return;
    try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();

        const now = audioCtx.currentTime;
        if (type === 'success') {
            const osc1 = audioCtx.createOscillator();
            const osc2 = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc1.type = 'sine';
            osc2.type = 'triangle';
            osc1.frequency.setValueAtTime(659.25, now);
            osc1.frequency.setValueAtTime(880.00, now + 0.09);
            osc2.frequency.setValueAtTime(1318.5, now);
            osc2.frequency.setValueAtTime(1760.0, now + 0.09);
            gain.gain.setValueAtTime(0.14, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
            osc1.connect(gain);
            osc2.connect(gain);
            gain.connect(audioCtx.destination);
            osc1.start(now);
            osc2.start(now);
            osc1.stop(now + 0.35);
            osc2.stop(now + 0.35);
        } else {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(220, now);
            osc.frequency.linearRampToValueAtTime(140, now + 0.25);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start(now);
            osc.stop(now + 0.28);
        }
    } catch (e) {}
}

function toggleSound() {
    soundEnabled = !soundEnabled;
    localStorage.setItem('dongm_sound', soundEnabled ? 'on' : 'off');
    updateSoundUI();
    if (soundEnabled) notify('Đã bật âm thanh thông báo!');
}

function updateSoundUI() {
    document.querySelectorAll('.soundIconCls').forEach(icon => {
        icon.className = soundEnabled ? 'soundIconCls fa-solid fa-volume-high text-indigo-500' : 'soundIconCls fa-solid fa-volume-xmark text-slate-400';
    });
}

// Khởi tạo ứng dụng
document.addEventListener('DOMContentLoaded', () => {
    updateSoundUI();
    preInitAceEditor();
    restoreSavedMySQLInputs();
    loadDir('');
    measurePing();
    setInterval(measurePing, 15000);
    initDragDrop();

    document.addEventListener('keydown', e => {
        if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
            e.preventDefault();
            document.getElementById('searchInput').focus();
        }
        if (e.key === 'Enter' && !document.getElementById('actionModal').classList.contains('hidden')) {
            e.preventDefault();
            submitActionModal();
        }
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !document.getElementById('sqlModal').classList.contains('hidden')) {
            e.preventDefault();
            executeSqlQuery();
        }
    });
});

function notify(msg, type = 'ok') {
    playSound(type === 'ok' ? 'success' : 'error');
    const box = document.getElementById('toastBox');
    const el = document.createElement('div');
    const color = type === 'ok'
        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white'
        : 'bg-gradient-to-r from-rose-600 to-red-600 text-white';
    el.className = `${color} px-3.5 py-2.5 rounded-2xl shadow-xl text-xs font-semibold flex items-center gap-2 pointer-events-auto transition-all duration-300 max-w-full`;
    el.innerHTML = `<i class="fa-solid ${type === 'ok' ? 'fa-circle-check' : 'fa-triangle-exclamation'} shrink-0"></i><span class="truncate">${msg}</span>`;
    box.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; setTimeout(() => el.remove(), 300); }, 2800);
}

async function apiCall(action, data = {}, isGet = false, loadingLabel = 'Đang tải dữ liệu...') {
    let url = `api.php?api=${action}`;
    let options = { headers: {} };
    if (isGet) {
        const params = new URLSearchParams(data).toString();
        if (params) url += `&${params}`;
    } else {
        options.method = 'POST';
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(data);
    }
    startLoading(loadingLabel);
    const t0 = performance.now();
    try {
        const res = await fetch(url, options);
        const ms = Math.max(1, Math.round(performance.now() - t0));
        const pingEl = document.getElementById('pingValue');
        if (pingEl) {
            pingEl.textContent = ms + ' ms';
            pingEl.className = 'font-mono font-bold ' + (ms < 80 ? 'text-emerald-400' : (ms < 200 ? 'text-amber-400' : 'text-rose-400'));
        }
        const text = await res.text();
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { status: 'error', message: 'Phản hồi máy chủ không đúng định dạng JSON.' };
        }
    } catch (netErr) {
        return { status: 'error', message: 'Không thể kết nối tới máy chủ.' };
    } finally {
        stopLoading();
    }
}

async function loadDir(path, manualRefresh = false) {
    const card = document.getElementById('fileTableCard');
    if (card) card.classList.add('opacity-60');
    const res = await apiCall('list', { path }, true, 'Đang mở thư mục...');
    if (card) card.classList.remove('opacity-60');

    if (res.status !== 'ok') {
        document.getElementById('itemSummary').textContent = 'Lỗi tải dữ liệu';
        return notify(res.message || 'Lỗi tải thư mục', 'error');
    }
    currentPath = res.path || '';
    currentItems = res.items || [];
    selectedPaths.clear();
    document.getElementById('checkAll').checked = false;
    updateBulkBar();
    renderBreadcrumb();
    renderTable();

    document.getElementById('currentFolderSize').textContent = formatSize(res.directFilesSize || 0);
    const deepBtn = document.getElementById('deepSizeBtn');
    if (deepBtn) {
        deepBtn.classList.remove('hidden');
        deepBtn.innerHTML = `<i class="fa-solid fa-calculator text-[10px]"></i><span>Tính sâu (+Thư mục con)</span>`;
    }

    if (res.server) renderServerSpecs(res.server);
    if (res.login_logs) renderLoginHistory(res.login_logs);

    if (res.mysql_state && !mysqlSessionRestored) {
        mysqlSessionRestored = true;
        applyMySQLConnectedUI(res.mysql_state);
    }
    if (manualRefresh) notify('Đã làm mới danh sách tệp!');
}

// ================= HIỂN THỊ & XÓA LỊCH SỬ ĐĂNG NHẬP =================
function renderLoginHistory(logs) {
    const box = document.getElementById('loginHistoryList');
    if (!box) return;
    if (!logs || !logs.length) {
        box.innerHTML = `<div class="text-[11px] text-slate-400 text-center py-3">Chưa có lịch sử đăng nhập</div>`;
        return;
    }
    box.innerHTML = logs.map((log, idx) => {
        const ok = log.success !== false;
        const badge = idx === 0 && ok
            ? `<span class="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold">Hiện tại</span>`
            : `<span class="text-[9px] px-1.5 py-0.5 rounded ${ok ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/15 text-rose-400 font-bold'}">${ok ? 'Thành công' : 'Sai MK'}</span>`;
        return `
            <div class="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border ${ok ? 'border-slate-200/70 dark:border-slate-800/80' : 'border-rose-500/30'} flex items-center justify-between gap-2 text-[11px]">
                <div class="flex items-center gap-2 min-w-0">
                    <div class="w-6 h-6 rounded-lg ${ok ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'} flex items-center justify-center shrink-0 text-[10px]">
                        <i class="fa-solid ${ok ? 'fa-shield-check' : 'fa-triangle-exclamation'}"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="flex items-center gap-1.5">
                            <span class="font-mono font-bold truncate">${escapeHtml(log.ip || 'Unknown')}</span>
                            ${badge}
                        </div>
                        <div class="text-[10px] text-slate-400 truncate">${escapeHtml(log.device || '')} • ${escapeHtml(log.time || '')}</div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

async function clearLoginHistory() {
    if (!confirm('Xóa toàn bộ lịch sử đăng nhập trước đó?')) return;
    const res = await apiCall('clear_logs', {}, false, 'Đang xóa lịch sử đăng nhập...');
    if (res.status === 'ok') {
        renderLoginHistory(res.logs || []);
        notify('Đã dọn sạch lịch sử đăng nhập!');
    } else {
        notify(res.message, 'error');
    }
}

function copyCurrentPath() {
    const text = '/' + currentPath;
    navigator.clipboard.writeText(text);
    notify(`Đã sao chép đường dẫn: ${text}`);
}

async function calculateDeepFolderSize() {
    const btn = document.getElementById('deepSizeBtn');
    if (btn) btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[10px]"></i><span>Đang tính...</span>`;
    const res = await apiCall('dir_size', { path: currentPath }, false, 'Đang tính tổng dung lượng thư mục...');
    if (res.status === 'ok') {
        document.getElementById('currentFolderSize').textContent = formatSize(res.deepSize) + ' (Gồm thư mục con)';
        if (btn) btn.classList.add('hidden');
        notify('Đã tính xong tổng dung lượng thư mục!');
    } else {
        notify(res.message, 'error');
    }
}

function renderServerSpecs(srv) {
    if (srv.chunk_size) {
        dynamicChunkSize = srv.chunk_size;
        const sub = document.getElementById('chunkModeSubText');
        if (sub) sub.textContent = `Cắt mảnh tự động ${formatSize(dynamicChunkSize)}/gói (Vượt giới hạn ${srv.upload_ini} của Host)`;
    }
    const pct = srv.disk_total > 0 ? Math.min(100, Math.round((srv.disk_used / srv.disk_total) * 100)) : 0;
    document.getElementById('diskPercentBadge').textContent = `${pct}%`;
    document.getElementById('diskSubText').textContent = `Trống ${formatSize(srv.disk_free)}`;
    document.getElementById('diskBar').style.width = `${pct}%`;
    document.getElementById('diskUsed').textContent = formatSize(srv.disk_used);
    document.getElementById('diskFree').textContent = formatSize(srv.disk_free);
    document.getElementById('diskTotal').textContent = formatSize(srv.disk_total);

    document.getElementById('srvIp').textContent = srv.server_ip;
    document.getElementById('clientIp').textContent = srv.client_ip;
    document.getElementById('srvPhp').textContent = srv.php_version;
    document.getElementById('srvSoft').textContent = srv.software;
    document.getElementById('srvSoft').title = srv.software;
    document.getElementById('srvOs').textContent = srv.os;
    document.getElementById('srvOs').title = srv.os;
    document.getElementById('srvUploadIni').textContent = `${srv.upload_ini} (Chunk ${formatSize(dynamicChunkSize)})`;

    const exts = [
        { name: 'ZipArchive', icon: 'fa-file-zipper', ok: srv.ext_zip },
        { name: 'MySQLi/PDO', icon: 'fa-database',    ok: srv.ext_mysqli },
        { name: 'cURL',       icon: 'fa-globe',       ok: srv.ext_curl },
        { name: 'Mbstring',   icon: 'fa-font',        ok: srv.ext_mb }
    ];
    document.getElementById('srvExts').innerHTML = exts.map(e => `
        <div class="px-2.5 py-1.5 rounded-xl border ${e.ok ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' : 'bg-rose-500/5 border-rose-500/20 text-rose-400'} flex items-center justify-between font-medium">
            <span class="flex items-center gap-1.5 truncate"><i class="fa-solid ${e.icon} text-[10px] opacity-80"></i> ${e.name}</span>
            <i class="fa-solid ${e.ok ? 'fa-circle-check' : 'fa-circle-xmark'} shrink-0"></i>
        </div>
    `).join('');
}

function renderBreadcrumb() {
    const nav = document.getElementById('breadcrumb');
    const parts = currentPath ? currentPath.split('/') : [];
    let html = `<button onclick="loadDir('')" class="px-2 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-indigo-500 flex items-center gap-1 transition shrink-0"><i class="fa-solid fa-house"></i> Root</button>`;
    let acc = '';
    parts.forEach((p, idx) => {
        acc = acc ? `${acc}/${p}` : p;
        const target = acc;
        html += `<span class="text-slate-400 shrink-0">/</span>
                 <button onclick="loadDir('${escapeQuotes(target)}')" class="px-2 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition shrink-0 ${idx === parts.length - 1 ? 'font-bold text-slate-900 dark:text-white' : 'text-slate-500'}">${escapeHtml(p)}</button>`;
    });
    nav.innerHTML = html;
}

function getIconBadge(item) {
    if (item.isDir) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-500/15 border border-amber-500/25 text-amber-400 flex items-center justify-center shrink-0 shadow-sm"><i class="fa-solid fa-folder text-sm sm:text-base"></i></div>`;
    }
    const ext = item.ext;
    if (['php'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/25 text-indigo-400 flex items-center justify-center shrink-0"><i class="fa-brands fa-php text-base sm:text-lg"></i></div>`;
    }
    if (['js','ts'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-yellow-500/15 border border-yellow-500/25 text-yellow-400 flex items-center justify-center shrink-0"><i class="fa-brands fa-js text-sm sm:text-base"></i></div>`;
    }
    if (['html','htm'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-orange-500/15 border border-orange-500/25 text-orange-400 flex items-center justify-center shrink-0"><i class="fa-brands fa-html5 text-sm sm:text-base"></i></div>`;
    }
    if (['css'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-500/15 border border-sky-500/25 text-sky-400 flex items-center justify-center shrink-0"><i class="fa-brands fa-css3-alt text-sm sm:text-base"></i></div>`;
    }
    if (['zip','rar','tar','gz','7z'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0"><i class="fa-solid fa-file-zipper text-sm sm:text-base"></i></div>`;
    }
    if (IMAGE_EXT.includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-pink-500/15 border border-pink-500/25 text-pink-400 flex items-center justify-center shrink-0"><i class="fa-solid fa-image text-sm sm:text-base"></i></div>`;
    }
    if (['sql','json','xml','yml','yaml'].includes(ext)) {
        return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/25 text-emerald-400 flex items-center justify-center shrink-0"><i class="fa-solid fa-database text-xs sm:text-sm"></i></div>`;
    }
    return `<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-slate-500/10 border border-slate-500/20 text-slate-400 flex items-center justify-center shrink-0"><i class="fa-regular fa-file-lines text-sm sm:text-base"></i></div>`;
}

function changeSort(field) {
    if (sortField === field) {
        sortAsc = !sortAsc;
    } else {
        sortField = field;
        sortAsc = true;
    }
    ['name', 'size', 'mtime'].forEach(f => {
        const icon = document.getElementById('sortIcon_' + f);
        if (!icon) return;
        if (f === sortField) {
            icon.className = `fa-solid ${sortAsc ? 'fa-arrow-up-short-wide' : 'fa-arrow-down-wide-short'} text-indigo-400 text-[10px]`;
        } else {
            icon.className = 'fa-solid fa-sort text-[10px] opacity-40';
        }
    });
    renderTable();
}

function renderTable() {
    const tbody = document.getElementById('fileListBody');
    const keyword = document.getElementById('searchInput').value.trim().toLowerCase();
    let filtered = currentItems.filter(i => i.name.toLowerCase().includes(keyword));

    filtered.sort((a, b) => {
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        let cmp = 0;
        if (sortField === 'name') {
            cmp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
        } else if (sortField === 'size') {
            cmp = (a.size || 0) - (b.size || 0);
        } else if (sortField === 'mtime') {
            cmp = (a.mtime || 0) - (b.mtime || 0);
        }
        return sortAsc ? cmp : -cmp;
    });

    let html = '';
    if (currentPath !== '') {
        const parentPath = currentPath.includes('/') ? currentPath.substring(0, currentPath.lastIndexOf('/')) : '';
        html += `
        <tr onclick="loadDir('${escapeQuotes(parentPath)}')" class="hover:bg-slate-100/70 dark:hover:bg-slate-800/50 cursor-pointer transition">
            <td class="py-2.5 pl-3 sm:pl-4 pr-1.5"></td>
            <td colspan="5" class="py-2.5 px-2 text-xs font-bold text-slate-400 flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-xl bg-slate-500/10 flex items-center justify-center"><i class="fa-solid fa-turn-up"></i></div>
                <span>.. (Quay về thư mục cha)</span>
            </td>
        </tr>`;
    }

    if (filtered.length === 0) {
        html += `<tr><td colspan="6" class="py-14 text-center text-xs text-slate-400"><i class="fa-regular fa-folder-open text-2xl mb-2 block opacity-50"></i>Thư mục trống hoặc không tìm thấy tệp phù hợp</td></tr>`;
    }

    filtered.forEach(item => {
        const checked = selectedPaths.has(item.rel) ? 'checked' : '';
        const isEditable = !item.isDir && (EDITABLE_EXT.includes(item.ext) || item.size < 300 * 1024);
        const isImage = !item.isDir && IMAGE_EXT.includes(item.ext);
        const isZip = !item.isDir && item.ext === 'zip';

        let clickAction = '';
        if (item.isDir) {
            clickAction = `loadDir('${escapeQuotes(item.rel)}')`;
        } else if (isZip) {
            clickAction = `previewZip('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}')`;
        } else if (isImage) {
            clickAction = `previewImage('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}')`;
        } else if (isEditable) {
            clickAction = `openEditor('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}', ${item.mtime})`;
        }

        html += `
        <tr class="group hover:bg-indigo-500/[0.06] dark:hover:bg-indigo-500/[0.07] transition">
            <td class="py-2.5 pl-3 sm:pl-4 pr-1.5 align-middle">
                <input type="checkbox" ${checked} onchange="toggleSelectItem('${escapeQuotes(item.rel)}', this.checked)" class="row-check w-3.5 h-3.5 rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer">
            </td>
            <td class="py-2.5 px-2 min-w-0 align-middle">
                <div onclick="${clickAction}" class="flex items-center gap-2.5 sm:gap-3 cursor-pointer min-w-0">
                    ${getIconBadge(item)}
                    <div class="min-w-0 flex-1 py-0.5">
                        <div class="font-semibold text-slate-800 dark:text-slate-100 truncate leading-normal py-0.5 group-hover:text-indigo-400 transition">${escapeHtml(item.name)}</div>
                        <div class="sm:hidden text-[10px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                            <span>${item.isDir ? 'Thư mục' : formatSize(item.size)}</span>
                            <span>•</span>
                            <span onclick="event.stopPropagation();openActionModal('chmod','${escapeQuotes(item.rel)}','${item.perms}')" class="text-indigo-400">${item.perms}</span>
                        </div>
                    </div>
                </div>
            </td>
            <td class="py-2.5 px-3 hidden sm:table-cell text-xs text-slate-400 font-mono whitespace-nowrap align-middle">${item.isDir ? '—' : formatSize(item.size)}</td>
            <td class="py-2.5 px-2.5 hidden md:table-cell whitespace-nowrap align-middle">
                <button onclick="openActionModal('chmod', '${escapeQuotes(item.rel)}', '${item.perms}')" class="text-[11px] font-mono px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800/90 hover:bg-indigo-500/20 hover:text-indigo-400 transition">${item.perms}</button>
            </td>
            <td class="py-2.5 px-2.5 hidden xl:table-cell text-xs text-slate-400 whitespace-nowrap align-middle">${formatDate(item.mtime)}</td>
            <td class="py-2.5 pl-1 pr-3 sm:pr-4 text-right whitespace-nowrap align-middle">
                <div class="flex items-center justify-end gap-0.5 sm:gap-1">
                    ${isZip ? `<button onclick="previewZip('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}')" class="w-7 h-7 rounded-lg hover:bg-amber-500/15 text-slate-400 hover:text-amber-400" title="Xem trước gói ZIP"><i class="fa-solid fa-eye text-[11px]"></i></button>` : ''}
                    ${isZip ? `<button onclick="unzipItem('${escapeQuotes(item.rel)}')" class="w-7 h-7 rounded-lg hover:bg-amber-500/15 text-slate-400 hover:text-amber-400" title="Giải nén ZIP"><i class="fa-solid fa-box-open text-[11px]"></i></button>` : ''}
                    ${!isZip ? `<button onclick="openZipModal(['${escapeQuotes(item.rel)}'], '${escapeQuotes(item.name)}')" class="w-7 h-7 rounded-lg hover:bg-amber-500/15 text-slate-400 hover:text-amber-400" title="Nén ZIP mục này"><i class="fa-solid fa-file-zipper text-[11px]"></i></button>` : ''}
                    ${isEditable ? `<button onclick="openEditor('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}', ${item.mtime})" class="w-7 h-7 rounded-lg hover:bg-indigo-500/15 text-slate-400 hover:text-indigo-400" title="Sửa nội dung"><i class="fa-solid fa-pen-to-square text-[11px]"></i></button>` : ''}
                    ${!item.isDir ? `<a href="api.php?download=${encodeURIComponent(item.rel)}" class="w-7 h-7 rounded-lg hover:bg-emerald-500/15 text-slate-400 hover:text-emerald-400 flex items-center justify-center" title="Tải về"><i class="fa-solid fa-download text-[11px]"></i></a>` : ''}
                    <button onclick="openActionModal('rename', '${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}')" class="w-7 h-7 rounded-lg hover:bg-sky-500/15 text-slate-400 hover:text-sky-400" title="Đổi tên"><i class="fa-solid fa-i-cursor text-[11px]"></i></button>
                    <button onclick="deleteSingle('${escapeQuotes(item.rel)}', '${escapeQuotes(item.name)}')" class="w-7 h-7 rounded-lg hover:bg-rose-500/15 text-slate-400 hover:text-rose-400" title="Xóa"><i class="fa-solid fa-trash text-[11px]"></i></button>
                </div>
            </td>
        </tr>`;
    });

    tbody.innerHTML = html;
    const dirCount = filtered.filter(i => i.isDir).length;
    const fileCount = filtered.length - dirCount;
    document.getElementById('itemSummary').textContent = `Hiển thị: ${dirCount} thư mục, ${fileCount} tệp`;
}

// ================= HỘP THOẠI THAO TÁC THÔNG MINH =================
function openActionModal(type, targetRel = '', initialVal = '') {
    currentActionModal = { type, targetRel, oldName: initialVal };
    const modal   = document.getElementById('actionModal');
    const title   = document.getElementById('actionModalTitle');
    const sub     = document.getElementById('actionModalSub');
    const icon    = document.getElementById('actionModalIcon');
    const input   = document.getElementById('actionModalInput');
    const presets = document.getElementById('chmodPresets');

    presets.classList.add('hidden');
    document.getElementById('actionModalDupWarn').classList.add('hidden');

    if (type === 'mkfile') {
        title.textContent = 'Tạo tệp tin mới';
        sub.textContent   = 'Nhập tên tệp kèm phần mở rộng (VD: index.php, style.css)';
        icon.className    = 'fa-solid fa-file-circle-plus text-emerald-400';
        input.value       = '';
        input.placeholder = 'ten_tep_moi.php';
    } else if (type === 'mkdir') {
        title.textContent = 'Tạo thư mục mới';
        sub.textContent   = 'Nhập tên thư mục cần khởi tạo tại đây';
        icon.className    = 'fa-solid fa-folder-plus text-amber-400';
        input.value       = '';
        input.placeholder = 'ten_thu_muc';
    } else if (type === 'rename') {
        title.textContent = 'Đổi tên tệp / thư mục';
        sub.textContent   = `Tên hiện tại: ${initialVal}`;
        icon.className    = 'fa-solid fa-i-cursor text-sky-400';
        input.value       = initialVal;
    } else if (type === 'chmod') {
        title.textContent = 'Thay đổi quyền truy cập (CHMOD)';
        sub.textContent   = `Mục: ${targetRel}`;
        icon.className    = 'fa-solid fa-shield-halved text-purple-400';
        input.value       = initialVal;
        presets.classList.remove('hidden');
    }

    modal.classList.remove('hidden');
    setTimeout(() => { input.focus(); input.select(); }, 40);
}

function setActionInputVal(val) {
    const input = document.getElementById('actionModalInput');
    input.value = val;
    input.focus();
}

function closeActionModal() {
    document.getElementById('actionModal').classList.add('hidden');
}

function validateActionModalInput() {
    const { type, oldName } = currentActionModal;
    const val = document.getElementById('actionModalInput').value.trim();
    const warn = document.getElementById('actionModalDupWarn');
    const warnTxt = document.getElementById('actionModalDupText');

    if (type === 'chmod' || !val) {
        warn.classList.add('hidden');
        return;
    }
    if (isDuplicateName(val, type === 'rename' ? oldName : '')) {
        warnTxt.textContent = type === 'mkfile'
            ? `Trùng tên: "${val}" đã tồn tại (Sẽ ghi đè nếu tiếp tục)!`
            : `Trùng tên: "${val}" đã tồn tại trong thư mục này!`;
        warn.classList.remove('hidden');
    } else {
        warn.classList.add('hidden');
    }
}

async function submitActionModal() {
    const { type, targetRel, oldName } = currentActionModal;
    const val = document.getElementById('actionModalInput').value.trim();
    if (!val) return notify('Vui lòng không để trống thông tin!', 'error');

    if (type === 'mkdir') {
        if (isDuplicateName(val)) return notify(`Trùng tên: "${val}" đã tồn tại!`, 'error');
        closeActionModal();
        const res = await apiCall('mkdir', { path: currentPath, name: val }, false, 'Đang tạo thư mục...');
        if (res.status === 'ok') { notify('Đã tạo thư mục mới!'); loadDir(currentPath); }
        else notify(res.message, 'error');
    } else if (type === 'mkfile') {
        let overwrite = false;
        if (isDuplicateName(val)) {
            if (!confirm(`Tệp "${val}" đã tồn tại! Bạn có muốn ghi đè tệp mới lên không?`)) return;
            overwrite = true;
        }
        closeActionModal();
        const res = await apiCall('mkfile', { path: currentPath, name: val, overwrite }, false, 'Đang tạo tệp...');
        if (res.status === 'ok') {
            notify('Đã tạo tệp tin mới!');
            await loadDir(currentPath);
            const rel = currentPath ? `${currentPath}/${val}` : val;
            fileContentCache.set(rel, { content: '', mtime: Math.floor(Date.now() / 1000) });
            openEditor(rel, val);
        } else notify(res.message, 'error');
    } else if (type === 'rename') {
        if (val === oldName) return closeActionModal();
        if (isDuplicateName(val, oldName)) return notify(`Trùng tên: "${val}" đã tồn tại!`, 'error');
        closeActionModal();
        const res = await apiCall('rename', { path: targetRel, newName: val }, false, 'Đang đổi tên...');
        if (res.status === 'ok') {
            fileContentCache.delete(targetRel);
            notify('Đổi tên thành công!');
            loadDir(currentPath);
        } else notify(res.message, 'error');
    } else if (type === 'chmod') {
        closeActionModal();
        const res = await apiCall('chmod', { path: targetRel, perms: val }, false, 'Đang cập nhật CHMOD...');
        if (res.status === 'ok') { notify('Cập nhật CHMOD thành công!'); loadDir(currentPath); }
        else notify(res.message, 'error');
    }
}

// ================= BỘ NHỚ TẠM (COPY / CUT / PASTE) =================
function setClipboard(mode) {
    if (!selectedPaths.size) return;
    clipboardState = { mode, paths: Array.from(selectedPaths) };
    const bar  = document.getElementById('clipboardBar');
    const info = document.getElementById('clipboardInfo');
    bar.classList.remove('hidden');
    bar.classList.add('flex');
    info.textContent = `${mode === 'cut' ? 'Cắt' : 'Chép'} ${clipboardState.paths.length} mục`;
    notify(`Đã đưa ${clipboardState.paths.length} mục vào bộ nhớ tạm. Hãy mở thư mục đích và bấm "Dán vào đây"!`);
}

function clearClipboard() {
    clipboardState = { mode: '', paths: [] };
    const bar = document.getElementById('clipboardBar');
    bar.classList.add('hidden');
    bar.classList.remove('flex');
}

async function pasteClipboard() {
    if (!clipboardState.paths.length) return;
    const res = await apiCall('paste', {
        dest: currentPath,
        paths: clipboardState.paths,
        mode: clipboardState.mode
    }, false, 'Đang dán dữ liệu...');
    if (res.status === 'ok') {
        notify(`Đã dán thành công ${res.count} mục!`);
        clearClipboard();
        loadDir(currentPath);
    } else {
        notify(res.message, 'error');
    }
}

// ================= TRÌNH NÉN ZIP CHUYÊN NGHIỆP =================
function openZipModal(customPaths = null, singleItemName = '') {
    pendingZipTargets = customPaths ? customPaths : Array.from(selectedPaths);
    if (!pendingZipTargets.length) return notify('Hãy chọn ít nhất 1 mục để nén!', 'error');

    const prefix = singleItemName ? singleItemName.replace(/\.[^/.]+$/, '') : 'backup';
    const suggested = generateTimestampZipName(prefix);
    document.getElementById('zipBuilderCountInfo').textContent = `Đóng gói ${pendingZipTargets.length} mục đã chọn`;
    document.getElementById('zipNameInput').value = suggested;
    checkZipDuplicateLive();
    document.getElementById('zipBuilderModal').classList.remove('hidden');
}

function closeZipModal() {
    document.getElementById('zipBuilderModal').classList.add('hidden');
}

function checkZipDuplicateLive() {
    let name = document.getElementById('zipNameInput').value.trim();
    if (!name) return;
    if (!name.toLowerCase().endsWith('.zip')) name += '.zip';
    const warn = document.getElementById('zipDupWarn');
    if (isDuplicateName(name)) {
        warn.classList.remove('hidden');
    } else {
        warn.classList.add('hidden');
    }
}

async function confirmZipCreation() {
    let zipName = document.getElementById('zipNameInput').value.trim();
    if (!zipName) zipName = generateTimestampZipName();
    if (!zipName.toLowerCase().endsWith('.zip')) zipName += '.zip';

    const level = parseInt(document.getElementById('zipLevelSelect').value, 10);
    let overwrite = false;
    if (isDuplicateName(zipName)) {
        if (!confirm(`CẢNH BÁO TRÙNG TÊN:\nTệp "${zipName}" đã tồn tại trong thư mục này.\nBạn có muốn GHI ĐÈ lên tệp ZIP cũ không?`)) {
            return;
        }
        overwrite = true;
    }

    closeZipModal();
    const res = await apiCall('zip', {
        path: currentPath,
        paths: pendingZipTargets,
        zipName,
        level,
        overwrite
    }, false, 'Đang nén gói ZIP...');

    if (res.status === 'ok') {
        notify(`Đã nén ${res.addedFiles} tệp vào ${res.zipName} (${formatSize(res.zipSize)})!`);
        loadDir(currentPath);
    } else {
        notify(res.message, 'error');
    }
}

// ================= XEM TRƯỚC FILE .ZIP =================
async function previewZip(rel, name) {
    const res = await apiCall('zip_preview', { path: rel }, false, `Đang đọc gói ${name}...`);
    if (res.status !== 'ok') return notify(res.message, 'error');

    document.getElementById('zipPreviewTitle').textContent = name;
    const ratio = res.totalSize > 0 ? Math.round((1 - res.totalComp / res.totalSize) * 100) : 0;
    document.getElementById('zipPreviewMeta').textContent = `${res.totalCount} mục • Gốc: ${formatSize(res.totalSize)} • Nén: ${formatSize(res.totalComp)} (-${ratio}%)`;

    const extractBtn = document.getElementById('zipPreviewExtractBtn');
    extractBtn.onclick = () => {
        closeZipPreviewModal();
        unzipItem(rel);
    };

    const tbody = document.getElementById('zipPreviewBody');
    if (!res.entries.length) {
        tbody.innerHTML = `<tr><td colspan="4" class="py-10 text-center text-slate-400">File ZIP rỗng</td></tr>`;
    } else {
        tbody.innerHTML = res.entries.map(e => `
            <tr class="hover:bg-indigo-500/5">
                <td class="py-2 px-3 flex items-center gap-2 truncate max-w-[200px] sm:max-w-md">
                    <i class="fa-solid ${e.isDir ? 'fa-folder text-amber-400' : 'fa-file text-slate-400'}"></i>
                    <span class="${e.isDir ? 'font-bold text-amber-300' : ''} truncate">${escapeHtml(e.name)}</span>
                </td>
                <td class="py-2 px-2.5 text-slate-400 hidden sm:table-cell">${e.isDir ? '—' : formatSize(e.size)}</td>
                <td class="py-2 px-2.5 text-emerald-400">${e.isDir ? '—' : formatSize(e.comp)}</td>
                <td class="py-2 px-3 text-right text-slate-400 hidden md:table-cell">${formatDate(e.mtime)}</td>
            </tr>
        `).join('');
    }
    document.getElementById('zipPreviewModal').classList.remove('hidden');
}

function closeZipPreviewModal() {
    document.getElementById('zipPreviewModal').classList.add('hidden');
}

// ================= SMART CHUNKED UPLOAD =================
function openUploadModal() {
    document.getElementById('uploadDupBox').classList.add('hidden');
    document.getElementById('uploadModal').classList.remove('hidden');
}

function closeUploadModal() {
    document.getElementById('uploadModal').classList.add('hidden');
    document.getElementById('uploadProgressWrap').classList.add('hidden');
    document.getElementById('uploadDupBox').classList.add('hidden');
    document.getElementById('uploadInput').value = '';
    pendingUploadFiles = null;
}

function cancelActiveUpload() {
    uploadCancelRequested = true;
    if (currentUploadId) {
        fetch('api.php?api=upload_cancel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: currentPath, upload_id: currentUploadId })
        });
    }
    closeUploadModal();
    notify('Đã hủy tiến trình tải lên và dọn tệp tạm!', 'error');
}

function prepareFilesUpload(fileList) {
    if (!fileList || fileList.length === 0) return;

    for (let i = 0; i < fileList.length; i++) {
        if (fileList[i].size > MAX_UPLOAD_BYTES) {
            notify(`Tệp "${fileList[i].name}" vượt quá giới hạn 500MB!`, 'error');
            document.getElementById('uploadInput').value = '';
            return;
        }
    }

    pendingUploadFiles = Array.from(fileList);
    const duplicates = [];
    for (const f of pendingUploadFiles) {
        if (isDuplicateName(f.name)) {
            duplicates.push(f.name);
        }
    }

    if (duplicates.length > 0) {
        playSound('error');
        document.getElementById('uploadDupNames').textContent = duplicates.join(', ');
        document.getElementById('uploadDupBox').classList.remove('hidden');
        return;
    }

    executeUploadWithMode('overwrite');
}

async function sendSingleChunkWithRetry(formData, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await fetch('api.php?api=upload_chunk', {
                method: 'POST',
                body: formData
            });
            const res = await response.json();
            if (res.status === 'ok') return res;
            if (attempt === maxRetries) throw new Error(res.message || 'Lỗi ghi mảnh tệp trên máy chủ');
        } catch (err) {
            if (attempt === maxRetries) throw err;
            await new Promise(r => setTimeout(r, 600));
        }
    }
}

async function executeUploadWithMode(dupMode = 'overwrite') {
    if (!pendingUploadFiles || pendingUploadFiles.length === 0) return;
    document.getElementById('uploadDupBox').classList.add('hidden');

    const files = pendingUploadFiles;
    const totalFiles = files.length;
    const totalBytesAll = files.reduce((acc, f) => acc + f.size, 0);
    let uploadedBytesAll = 0;
    let successFilesCount = 0;
    uploadCancelRequested = false;

    const wrap   = document.getElementById('uploadProgressWrap');
    const bar    = document.getElementById('uploadBar');
    const pct    = document.getElementById('uploadPercent');
    const txt    = document.getElementById('uploadStatusText');
    const detail = document.getElementById('uploadChunkDetail');

    wrap.classList.remove('hidden');
    bar.style.width = '0%';
    pct.textContent = '0%';

    startLoading(`Đang tải lên ${totalFiles} tệp (Chunked Mode)...`);

    try {
        for (let fIdx = 0; fIdx < totalFiles; fIdx++) {
            if (uploadCancelRequested) break;

            const file = files[fIdx];
            const chunkSize = dynamicChunkSize || (2 * 1024 * 1024);
            const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
            currentUploadId = Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 8);

            for (let cIdx = 0; cIdx < totalChunks; cIdx++) {
                if (uploadCancelRequested) break;

                const start = cIdx * chunkSize;
                const end   = Math.min(file.size, start + chunkSize);
                const blob  = file.slice(start, end);

                txt.textContent = `[${fIdx + 1}/${totalFiles}] ${file.name}`;
                detail.textContent = `Mảnh ${cIdx + 1}/${totalChunks} (${formatSize(end)} / ${formatSize(file.size)})`;

                const fd = new FormData();
                fd.append('path', currentPath);
                fd.append('file_name', file.name);
                fd.append('upload_id', currentUploadId);
                fd.append('chunk_index', cIdx);
                fd.append('total_chunks', totalChunks);
                fd.append('dup_mode', dupMode);
                fd.append('chunk', blob, file.name);

                await sendSingleChunkWithRetry(fd, 3);

                uploadedBytesAll += (end - start);
                const overallPercent = totalBytesAll > 0 ? Math.min(100, Math.round((uploadedBytesAll / totalBytesAll) * 100)) : 100;
                bar.style.width = overallPercent + '%';
                pct.textContent = overallPercent + '%';
            }

            if (!uploadCancelRequested) {
                successFilesCount++;
            }
        }

        stopLoading();
        if (!uploadCancelRequested) {
            closeUploadModal();
            notify(`Đã tải lên thành công ${successFilesCount} tệp!`);
            loadDir(currentPath);
        }
    } catch (err) {
        stopLoading();
        closeUploadModal();
        notify(err.message || 'Lỗi trong quá trình ghép mảnh tệp!', 'error');
    }
}

function initDragDrop() {
    window.addEventListener('dragover', e => e.preventDefault());
    window.addEventListener('drop', e => {
        e.preventDefault();
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            openUploadModal();
            prepareFilesUpload(e.dataTransfer.files);
        }
    });
}

// ================= TRÌNH SỬA CODE TỨC THÌ =================
async function openEditor(rel, name, mtime = 0) {
    preInitAceEditor();
    editingPath = rel;
    document.getElementById('editorFileName').textContent = rel;

    const isDark = document.documentElement.classList.contains('dark');
    if (aceInstance) {
        aceInstance.setTheme(isDark ? "ace/theme/one_dark" : "ace/theme/chrome");
        const ext = name.split('.').pop().toLowerCase();
        const modeMap = { php:'php', js:'javascript', ts:'typescript', html:'html', css:'css', json:'json', sql:'sql', md:'markdown', xml:'xml', sh:'sh', py:'python', yml:'yaml', yaml:'yaml' };
        const modeName = modeMap[ext] || 'text';
        aceInstance.session.setMode("ace/mode/" + modeName);
        applyEditorWrapState();
        document.getElementById('editorModeInfo').textContent = `${modeName.toUpperCase()} • UTF-8`;
    }

    const modal   = document.getElementById('editorModal');
    const overlay = document.getElementById('editorLoadingOverlay');
    const badge   = document.getElementById('editorCacheBadge');
    modal.classList.remove('hidden');

    const cached = fileContentCache.get(rel);
    if (cached && (!mtime || cached.mtime === mtime)) {
        badge.classList.remove('hidden');
        overlay.classList.add('hidden');
        if (aceInstance) {
            aceInstance.setValue(cached.content, -1);
            applyEditorWrapState();
            aceInstance.resize(true);
            aceInstance.focus();
        }
        return;
    }

    badge.classList.add('hidden');
    overlay.classList.remove('hidden');
    if (aceInstance) aceInstance.setValue('', -1);

    const res = await apiCall('read', { path: rel }, false, `Đang nạp ${name}...`);
    overlay.classList.add('hidden');

    if (res.status !== 'ok') {
        closeEditor();
        return notify(res.message, 'error');
    }

    fileContentCache.set(rel, { content: res.content, mtime: res.mtime || mtime });
    if (aceInstance) {
        aceInstance.setValue(res.content, -1);
        applyEditorWrapState();
        aceInstance.resize(true);
        aceInstance.focus();
    }
}

async function saveFileContent() {
    if (!editingPath || !aceInstance) return;
    const newContent = aceInstance.getValue();
    const res = await apiCall('save', { path: editingPath, content: newContent }, false, 'Đang lưu tệp...');
    if (res.status === 'ok') {
        fileContentCache.set(editingPath, { content: newContent, mtime: res.mtime });
        notify('Đã lưu tệp tin thành công!');
        loadDir(currentPath);
    } else {
        notify(res.message, 'error');
    }
}

function closeEditor() {
    document.getElementById('editorModal').classList.add('hidden');
    editingPath = '';
}

function previewImage(rel, name) {
    document.getElementById('previewImg').src = `api.php?preview=${encodeURIComponent(rel)}&t=${Date.now()}`;
    document.getElementById('previewCaption').textContent = name;
    document.getElementById('previewModal').classList.remove('hidden');
}

async function deleteSingle(rel, name) {
    if (!confirm(`Bạn có chắc muốn xóa "${name}"?`)) return;
    const res = await apiCall('delete', { paths: [rel] }, false, 'Đang xóa...');
    if (res.status === 'ok') {
        fileContentCache.delete(rel);
        notify('Đã xóa mục được chọn!');
        loadDir(currentPath);
    } else notify(res.message, 'error');
}

async function bulkDelete() {
    if (!selectedPaths.size) return;
    if (!confirm(`Xóa vĩnh viễn ${selectedPaths.size} mục đã chọn?`)) return;
    const res = await apiCall('delete', { paths: Array.from(selectedPaths) }, false, 'Đang xóa hàng loạt...');
    if (res.status === 'ok') { notify(`Đã xóa ${selectedPaths.size} mục!`); loadDir(currentPath); }
    else notify(res.message, 'error');
}

async function unzipItem(rel) {
    if (!confirm(`Giải nén "${rel}" ngay tại thư mục này?`)) return;
    const res = await apiCall('unzip', { path: rel }, false, 'Đang giải nén ZIP...');
    if (res.status === 'ok') { notify('Giải nén hoàn tất!'); loadDir(currentPath); }
    else notify(res.message, 'error');
}

// ================= QUẢN TRỊ MYSQL & LƯU PHIÊN ĐĂNG NHẬP =================
function restoreSavedMySQLInputs() {
    try {
        const saved = JSON.parse(localStorage.getItem('dongm_mysql_cfg') || 'null');
        if (saved) {
            if (saved.host) document.getElementById('dbHost').value = saved.host;
            if (saved.port) document.getElementById('dbPort').value = saved.port;
            if (saved.user) document.getElementById('dbUser').value = saved.user;
            if (saved.db)   document.getElementById('dbName').value = saved.db;
        }
    } catch (e) {}
}

function applyMySQLConnectedUI(state) {
    document.getElementById('sqlBadgeDot').classList.remove('hidden');
    document.getElementById('sqlLoginBox').classList.add('hidden');
    document.getElementById('sqlConnectedBox').classList.remove('hidden');
    document.getElementById('sqlConnSummary').textContent = `${state.user}@${state.host}:${state.port || 3306}`;

    const select = document.getElementById('sqlDbSelect');
    select.innerHTML = (state.databases || []).map(d => `<option value="${escapeHtml(d)}" ${d === state.currentDb ? 'selected' : ''}>${escapeHtml(d)}</option>`).join('');
    renderMySQLTables(state.tables || [], state.currentDb);
}

async function connectMySQL() {
    const host = document.getElementById('dbHost').value.trim();
    const port = document.getElementById('dbPort').value.trim();
    const user = document.getElementById('dbUser').value.trim();
    const pass = document.getElementById('dbPass').value;
    const db   = document.getElementById('dbName').value.trim();

    if (!user) return notify('Vui lòng nhập Username MySQL!', 'error');

    const res = await apiCall('mysql_connect', { host, port, user, pass, db }, false, 'Đang kết nối MySQL...');
    if (res.status !== 'ok') return notify(res.message, 'error');

    localStorage.setItem('dongm_mysql_cfg', JSON.stringify({ host, port, user, db: res.currentDb || db }));
    notify('Đã kết nối & lưu phiên MySQL!');
    applyMySQLConnectedUI(res);
}

async function switchMySQLDatabase(dbName) {
    const res = await apiCall('mysql_switch_db', { db: dbName }, false, `Đang chuyển sang DB ${dbName}...`);
    if (res.status !== 'ok') return notify(res.message, 'error');
    notify(`Đã chuyển sang DB: ${dbName}`);
    renderMySQLTables(res.tables, res.currentDb);
}

function renderMySQLTables(tables, currentDb) {
    currentSqlDb = currentDb || '';
    currentTablesList = tables || [];
    document.getElementById('sqlModalDbBadge').textContent = currentDb || 'No DB';
    document.getElementById('sqlTableCount').textContent = `${tables.length} bảng`;

    const expSelect = document.getElementById('exportTableSelect');
    if (expSelect) {
        expSelect.innerHTML = `<option value="">-- Toàn bộ các bảng trong Database (${escapeHtml(currentSqlDb)}) --</option>` +
            tables.map(t => `<option value="${escapeHtml(t.name)}">Bảng: ${escapeHtml(t.name)} (${t.rows} dòng)</option>`).join('');
    }

    const box = document.getElementById('sqlTableList');
    if (!tables.length) {
        box.innerHTML = `<div class="p-4 text-center text-xs text-slate-400">Database này chưa có bảng nào</div>`;
        return;
    }
    box.innerHTML = tables.map(t => `
        <div class="px-3 py-2 hover:bg-indigo-500/10 flex items-center justify-between transition group">
            <div onclick="openSqlModal('${escapeQuotes(t.name)}', 'browse')" class="flex items-center gap-2 min-w-0 flex-1 cursor-pointer">
                <i class="fa-solid fa-table text-indigo-400 text-xs"></i>
                <span class="text-xs font-medium truncate group-hover:text-indigo-400">${escapeHtml(t.name)}</span>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
                <span class="text-[10px] font-mono text-slate-400">${t.rows} dòng</span>
                <button onclick="openSqlModal('${escapeQuotes(t.name)}', 'structure')" class="px-2 py-0.5 rounded bg-slate-200/70 dark:bg-slate-800 hover:bg-indigo-500 hover:text-white text-[10px] font-semibold transition">Cấu trúc</button>
            </div>
        </div>
    `).join('');
}

async function disconnectMySQL() {
    await apiCall('mysql_disconnect', {}, false, 'Đang ngắt kết nối MySQL...');
    document.getElementById('sqlBadgeDot').classList.add('hidden');
    document.getElementById('sqlConnectedBox').classList.add('hidden');
    document.getElementById('sqlLoginBox').classList.remove('hidden');
    notify('Đã xóa phiên kết nối MySQL!');
}

function switchPmaTab(tab) {
    const tabs = {
        browse:    document.getElementById('pmaTabBrowse'),
        structure: document.getElementById('pmaTabStruct'),
        sql:       document.getElementById('pmaTabSql'),
        export:    document.getElementById('pmaTabExport'),
        import:    document.getElementById('pmaTabImport')
    };
    const activeCls   = 'px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 bg-white dark:bg-slate-900 text-indigo-400 shadow-sm';
    const inactiveCls = 'px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 text-slate-400 hover:text-white';

    Object.keys(tabs).forEach(k => tabs[k].className = (k === tab ? activeCls : inactiveCls));

    const qBar    = document.getElementById('pmaQueryBar');
    const resBox  = document.getElementById('sqlResultContainer');
    const expPane = document.getElementById('pmaExportPane');
    const impPane = document.getElementById('pmaImportPane');

    qBar.classList.add('hidden');
    resBox.classList.add('hidden');
    expPane.classList.add('hidden');
    impPane.classList.add('hidden');

    if (tab === 'browse' || tab === 'sql') {
        qBar.classList.remove('hidden');
        resBox.classList.remove('hidden');
        if (tab === 'browse' && currentSqlTable) {
            document.getElementById('sqlQueryInput').value = `SELECT * FROM \`${currentSqlTable}\` LIMIT 50;`;
            executeSqlQuery();
        }
    } else if (tab === 'structure') {
        resBox.classList.remove('hidden');
        loadTableStructure(currentSqlTable);
    } else if (tab === 'export') {
        expPane.classList.remove('hidden');
        if (currentSqlTable) {
            document.getElementById('exportTableSelect').value = currentSqlTable;
        }
    } else if (tab === 'import') {
        impPane.classList.remove('hidden');
    }
}

function openSqlModal(tableName = '', mode = 'browse') {
    document.getElementById('sqlModal').classList.remove('hidden');
    if (tableName) {
        currentSqlTable = tableName;
        const badge = document.getElementById('sqlModalTableBadge');
        badge.textContent = tableName;
        badge.classList.remove('hidden');
    }
    switchPmaTab(mode);
}

function closeSqlModal() {
    document.getElementById('sqlModal').classList.add('hidden');
}

function setQuickSql(q) {
    switchPmaTab('sql');
    document.getElementById('sqlQueryInput').value = q;
    executeSqlQuery();
}

async function executeSqlQuery() {
    const sql = document.getElementById('sqlQueryInput').value.trim();
    if (!sql) return notify('Hãy nhập câu lệnh SQL!', 'error');

    const container = document.getElementById('sqlResultContainer');
    const meta      = document.getElementById('sqlExecMeta');
    container.innerHTML = `<div class="h-full flex items-center justify-center text-slate-400"><i class="fa-solid fa-spinner fa-spin mr-2"></i>Đang thực thi truy vấn...</div>`;

    const res = await apiCall('mysql_query', { sql }, false, 'Đang chạy truy vấn SQL...');
    if (res.status !== 'ok') {
        meta.textContent = 'Truy vấn gặp lỗi.';
        container.innerHTML = `<div class="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 font-mono text-xs">${escapeHtml(res.message)}</div>`;
        return notify('Lỗi cú pháp hoặc thực thi SQL!', 'error');
    }

    const r = res.result;
    notify(`Thực thi SQL thành công (${r.time_ms} ms)!`);

    if (!r.is_select) {
        meta.textContent = `Hoàn tất trong ${r.time_ms} ms • Dòng ảnh hưởng: ${r.affected}`;
        container.innerHTML = `<div class="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-medium text-xs">Câu lệnh thực thi thành công. Số bản ghi ảnh hưởng (Affected rows): <strong>${r.affected}</strong></div>`;
        return;
    }

    currentSqlTable   = r.table || currentSqlTable;
    currentSqlColumns = r.columns || [];
    currentSqlPk      = r.primary_key || '';
    currentSqlRows    = r.rows || [];

    const btnInsert = document.getElementById('btnInsertRow');
    const tblBadge  = document.getElementById('sqlModalTableBadge');
    if (currentSqlTable) {
        btnInsert.classList.remove('hidden');
        tblBadge.textContent = currentSqlTable;
        tblBadge.classList.remove('hidden');
    } else {
        btnInsert.classList.add('hidden');
    }

    const canEdit = Boolean(currentSqlTable && currentSqlPk);
    meta.innerHTML = `Trả về <strong>${r.count}</strong> dòng (${r.time_ms} ms) ` +
        (canEdit
            ? `• Khóa chính: <span class="text-emerald-400 font-mono font-bold">${escapeHtml(currentSqlPk)}</span>`
            : `• <span class="text-amber-400">Chế độ chỉ đọc</span>`);

    if (r.count === 0) {
        container.innerHTML = `<div class="p-10 text-center text-slate-400">Truy vấn hợp lệ nhưng không có bản ghi nào trả về (0 rows).</div>`;
        return;
    }

    let tbl = `<table class="w-full text-left border-collapse border border-slate-200 dark:border-slate-800 text-xs"><thead><tr class="bg-slate-100 dark:bg-slate-800/90 text-slate-600 dark:text-slate-200">`;
    if (canEdit) {
        tbl += `<th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700 font-bold text-center w-20">Sửa/Xóa</th>`;
    }
    r.columns.forEach(c => {
        const isPk = c === currentSqlPk;
        tbl += `<th class="py-2 px-3 border border-slate-200 dark:border-slate-700 font-mono font-bold whitespace-nowrap">
            ${isPk ? '<i class="fa-solid fa-key text-amber-400 mr-1" title="Primary Key"></i>' : ''}${escapeHtml(c)}
        </th>`;
    });
    tbl += `</tr></thead><tbody class="divide-y divide-slate-200 dark:divide-slate-800">`;

    r.rows.forEach((row, rIdx) => {
        tbl += `<tr class="hover:bg-indigo-500/10 transition group">`;
        if (canEdit) {
            tbl += `<td class="py-1.5 px-2 border border-slate-200/70 dark:border-slate-800 whitespace-nowrap text-center">
                <button onclick="openEditRowModal(${rIdx})" class="px-1.5 py-0.5 rounded bg-indigo-500/15 hover:bg-indigo-500 text-indigo-400 hover:text-white text-[11px] font-semibold mr-1 transition" title="Sửa dòng"><i class="fa-solid fa-pen"></i></button>
                <button onclick="deleteMySQLRow(${rIdx})" class="px-1.5 py-0.5 rounded bg-rose-500/15 hover:bg-rose-500 text-rose-400 hover:text-white text-[11px] font-semibold transition" title="Xóa dòng"><i class="fa-solid fa-trash"></i></button>
            </td>`;
        }
        r.columns.forEach(c => {
            const rawVal = row[c];
            const displayVal = rawVal === null
                ? '<span class="text-slate-400 italic">NULL</span>'
                : escapeHtml(String(rawVal).length > 160 ? String(rawVal).substring(0, 160) + '…' : String(rawVal));
            const dblClickAttr = canEdit ? `ondblclick="startInlineCellEdit(this, ${rIdx}, '${escapeQuotes(c)}')"` : '';
            tbl += `<td ${dblClickAttr} class="py-1.5 px-3 border border-slate-200/70 dark:border-slate-800 font-mono whitespace-nowrap max-w-[240px] truncate ${canEdit ? 'cursor-pointer hover:bg-indigo-500/15' : ''}" title="${canEdit ? 'Nhấp đúp để sửa trực tiếp' : ''}">${displayVal}</td>`;
        });
        tbl += `</tr>`;
    });
    tbl += `</tbody></table>`;
    container.innerHTML = tbl;
}

function startInlineCellEdit(td, rowIndex, colName) {
    if (td.querySelector('input, textarea')) return;
    const row = currentSqlRows[rowIndex];
    if (!row) return;
    const pkVal = row[currentSqlPk];
    const oldVal = row[colName] === null ? '' : String(row[colName]);

    const input = document.createElement('input');
    input.type = 'text';
    input.value = oldVal;
    input.className = 'w-full min-w-[120px] px-2 py-0.5 text-xs font-mono bg-slate-950 text-emerald-400 border border-indigo-500 rounded focus:outline-none';

    td.innerHTML = '';
    td.appendChild(input);
    input.focus();
    input.select();

    let finished = false;
    const finishEdit = async (save) => {
        if (finished) return;
        finished = true;
        const newVal = input.value;
        if (!save || newVal === oldVal) {
            td.innerHTML = row[colName] === null ? '<span class="text-slate-400 italic">NULL</span>' : escapeHtml(oldVal);
            return;
        }
        const res = await apiCall('mysql_update_cell', {
            table: currentSqlTable,
            pk_col: currentSqlPk,
            pk_val: pkVal,
            column: colName,
            value: newVal
        }, false, `Đang cập nhật cột ${colName}...`);

        if (res.status === 'ok') {
            row[colName] = newVal;
            td.innerHTML = escapeHtml(newVal);
            notify(`Đã lưu thay đổi cột "${colName}"!`);
        } else {
            td.innerHTML = escapeHtml(oldVal);
            notify(res.message, 'error');
        }
    };

    input.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); finishEdit(true); }
        if (e.key === 'Escape') { e.preventDefault(); finishEdit(false); }
    });
    input.addEventListener('blur', () => finishEdit(true));
}

function openEditRowModal(rowIndex) {
    const row = currentSqlRows[rowIndex];
    if (!row) return;
    const pkVal = row[currentSqlPk];

    document.getElementById('rowFormTitle').textContent = `Sửa dòng (${currentSqlPk} = ${pkVal}) — ${currentSqlTable}`;
    const box = document.getElementById('rowFormFields');
    box.innerHTML = currentSqlColumns.map(col => {
        const val = row[col] === null ? '' : String(row[col]);
        return `
            <div>
                <label class="text-[11px] font-mono font-bold text-slate-400 block mb-1">${escapeHtml(col)} ${col === currentSqlPk ? '<span class="text-amber-400">(PK)</span>' : ''}</label>
                <input data-col="${escapeHtml(col)}" type="text" value="${escapeHtml(val)}" class="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
            </div>
        `;
    }).join('');

    const btn = document.getElementById('rowFormSubmitBtn');
    btn.onclick = async () => {
        const inputs = box.querySelectorAll('input[data-col]');
        for (const inp of inputs) {
            const col = inp.getAttribute('data-col');
            const newVal = inp.value;
            const oldVal = row[col] === null ? '' : String(row[col]);
            if (newVal !== oldVal) {
                const res = await apiCall('mysql_update_cell', {
                    table: currentSqlTable,
                    pk_col: currentSqlPk,
                    pk_val: pkVal,
                    column: col,
                    value: newVal
                }, false, `Đang lưu ${col}...`);
                if (res.status !== 'ok') return notify(res.message, 'error');
            }
        }
        closeRowFormModal();
        notify('Đã cập nhật bản ghi thành công!');
        executeSqlQuery();
    };
    document.getElementById('rowFormModal').classList.remove('hidden');
}

function openInsertRowModal() {
    if (!currentSqlTable || !currentSqlColumns.length) return;
    document.getElementById('rowFormTitle').textContent = `Thêm dòng mới vào "${currentSqlTable}"`;
    const box = document.getElementById('rowFormFields');
    box.innerHTML = currentSqlColumns.map(col => `
        <div>
            <label class="text-[11px] font-mono font-bold text-slate-400 block mb-1">${escapeHtml(col)} ${col === currentSqlPk ? '<span class="text-slate-500">(Để trống nếu tự tăng)</span>' : ''}</label>
            <input data-col="${escapeHtml(col)}" type="text" placeholder="Nhập giá trị..." class="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
        </div>
    `).join('');

    const btn = document.getElementById('rowFormSubmitBtn');
    btn.onclick = async () => {
        const data = {};
        box.querySelectorAll('input[data-col]').forEach(inp => {
            if (inp.value !== '') data[inp.getAttribute('data-col')] = inp.value;
        });
        const res = await apiCall('mysql_insert_row', { table: currentSqlTable, data }, false, 'Đang thêm bản ghi...');
        if (res.status === 'ok') {
            closeRowFormModal();
            notify('Đã thêm dòng mới thành công!');
            executeSqlQuery();
        } else {
            notify(res.message, 'error');
        }
    };
    document.getElementById('rowFormModal').classList.remove('hidden');
}

function closeRowFormModal() {
    document.getElementById('rowFormModal').classList.add('hidden');
}

async function deleteMySQLRow(rowIndex) {
    const row = currentSqlRows[rowIndex];
    if (!row) return;
    const pkVal = row[currentSqlPk];
    if (!confirm(`Xác nhận xóa dòng có ${currentSqlPk} = "${pkVal}" khỏi bảng "${currentSqlTable}"?`)) return;

    const res = await apiCall('mysql_delete_row', {
        table: currentSqlTable,
        pk_col: currentSqlPk,
        pk_val: pkVal
    }, false, 'Đang xóa dòng...');

    if (res.status === 'ok') {
        notify('Đã xóa bản ghi!');
        executeSqlQuery();
    } else {
        notify(res.message, 'error');
    }
}

async function loadTableStructure(tableName) {
    const container = document.getElementById('sqlResultContainer');
    if (!tableName) {
        if (!currentTablesList.length) {
            container.innerHTML = `<div class="p-10 text-center text-slate-400">Hãy chọn một bảng ở cột bên phải để xem cấu trúc chi tiết.</div>`;
            return;
        }
        let html = `<div class="mb-2.5 font-bold text-xs">Danh sách bảng trong Database <span class="text-indigo-400 font-mono">${escapeHtml(currentSqlDb)}</span>:</div>`;
        html += `<table class="w-full text-left border-collapse border border-slate-200 dark:border-slate-800 text-xs"><thead><tr class="bg-slate-100 dark:bg-slate-800">
            <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Tên Bảng</th>
            <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Số dòng</th>
            <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700 hidden sm:table-cell">Engine</th>
            <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Kích thước</th>
            <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700 text-right">Thao tác</th>
        </tr></thead><tbody>`;
        currentTablesList.forEach(t => {
            html += `<tr class="hover:bg-indigo-500/5">
                <td class="py-2 px-2.5 border border-slate-200 dark:border-slate-800 font-mono font-bold text-indigo-400 cursor-pointer" onclick="openSqlModal('${escapeQuotes(t.name)}', 'browse')">${escapeHtml(t.name)}</td>
                <td class="py-2 px-2.5 border border-slate-200 dark:border-slate-800 font-mono">${t.rows}</td>
                <td class="py-2 px-2.5 border border-slate-200 dark:border-slate-800 hidden sm:table-cell">${escapeHtml(t.engine)}</td>
                <td class="py-2 px-2.5 border border-slate-200 dark:border-slate-800 font-mono">${formatSize(t.size)}</td>
                <td class="py-2 px-2.5 border border-slate-200 dark:border-slate-800 text-right whitespace-nowrap space-x-1">
                    <button onclick="openSqlModal('${escapeQuotes(t.name)}', 'browse')" class="px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-400 text-[11px] font-semibold">Duyệt</button>
                    <button onclick="openSqlModal('${escapeQuotes(t.name)}', 'structure')" class="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 text-[11px] font-semibold">Cột</button>
                    <button onclick="truncateOrDropTable('${escapeQuotes(t.name)}', 'TRUNCATE')" class="px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 text-[11px] font-semibold">Rỗng</button>
                    <button onclick="truncateOrDropTable('${escapeQuotes(t.name)}', 'DROP')" class="px-2 py-0.5 rounded bg-rose-500/15 text-rose-400 text-[11px] font-semibold">Xóa</button>
                </td>
            </tr>`;
        });
        html += `</tbody></table>`;
        container.innerHTML = html;
        return;
    }

    const res = await apiCall('mysql_table_structure', { table: tableName }, false, `Đang tải cấu trúc bảng ${tableName}...`);
    if (res.status !== 'ok') return notify(res.message, 'error');

    let html = `<div class="flex flex-wrap items-center justify-between gap-2 mb-2.5">
        <div class="font-bold text-xs sm:text-sm">Cấu trúc bảng <span class="text-indigo-400 font-mono">${escapeHtml(tableName)}</span></div>
        <div class="flex gap-1.5">
            <button onclick="currentSqlTable='';loadTableStructure('');" class="px-2.5 py-1 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-semibold">← DS Bảng</button>
            <button onclick="truncateOrDropTable('${escapeQuotes(tableName)}', 'TRUNCATE')" class="px-2.5 py-1 rounded-xl bg-amber-500/15 text-amber-400 text-xs font-semibold">TRUNCATE</button>
            <button onclick="truncateOrDropTable('${escapeQuotes(tableName)}', 'DROP')" class="px-2.5 py-1 rounded-xl bg-rose-500/15 text-rose-400 text-xs font-semibold">DROP</button>
        </div>
    </div>`;

    html += `<table class="w-full text-left border-collapse border border-slate-200 dark:border-slate-800 text-xs"><thead><tr class="bg-slate-100 dark:bg-slate-800">
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Tên Cột</th>
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Kiểu (Type)</th>
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Null</th>
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Khóa</th>
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Mặc định</th>
        <th class="py-2 px-2.5 border border-slate-200 dark:border-slate-700">Extra</th>
    </tr></thead><tbody>`;

    res.columns.forEach(c => {
        html += `<tr class="hover:bg-indigo-500/5 font-mono">
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800 font-bold ${c.Key === 'PRI' ? 'text-amber-400' : ''}">${c.Key === 'PRI' ? '<i class="fa-solid fa-key mr-1"></i>' : ''}${escapeHtml(c.Field)}</td>
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800 text-indigo-400">${escapeHtml(c.Type)}</td>
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800">${escapeHtml(c.Null)}</td>
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800 font-bold">${escapeHtml(c.Key)}</td>
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800">${c.Default === null ? '<span class="text-slate-500 italic">NULL</span>' : escapeHtml(c.Default)}</td>
            <td class="py-1.5 px-2.5 border border-slate-200 dark:border-slate-800 text-emerald-400">${escapeHtml(c.Extra)}</td>
        </tr>`;
    });
    html += `</tbody></table>`;
    container.innerHTML = html;
}

async function truncateOrDropTable(tableName, actionType) {
    const msg = actionType === 'DROP'
        ? `CẢNH BÁO: Xóa vĩnh viễn bảng "${tableName}"?`
        : `Làm rỗng toàn bộ dữ liệu (TRUNCATE) trong bảng "${tableName}"?`;
    if (!confirm(msg)) return;
    const sql = actionType === 'DROP' ? `DROP TABLE \`${tableName}\`;` : `TRUNCATE TABLE \`${tableName}\`;`;
    const res = await apiCall('mysql_query', { sql }, false, `Đang thực hiện ${actionType}...`);
    if (res.status === 'ok') {
        notify(`Đã thực hiện ${actionType} bảng ${tableName}!`);
        await switchMySQLDatabase(currentSqlDb);
        currentSqlTable = '';
        loadTableStructure('');
    } else {
        notify(res.message, 'error');
    }
}

function triggerSqlExport() {
    const tbl = document.getElementById('exportTableSelect').value;
    window.location.href = `api.php?mysql_export=1&table=${encodeURIComponent(tbl)}`;
    notify('Đang tạo và tải xuống file .SQL...');
}

async function executeSqlImport() {
    const fileInput = document.getElementById('importSqlFile');
    const textInput = document.getElementById('importSqlText');

    if ((!fileInput.files || !fileInput.files.length) && !textInput.value.trim()) {
        return notify('Vui lòng chọn file .sql hoặc dán mã SQL vào ô!', 'error');
    }

    const formData = new FormData();
    if (fileInput.files && fileInput.files.length) {
        formData.append('sql_file', fileInput.files[0]);
    }
    if (textInput.value.trim()) {
        formData.append('sql_text', textInput.value.trim());
    }

    startLoading('Đang Import dữ liệu SQL...');
    try {
        const res = await fetch('api.php?api=mysql_import', { method: 'POST', body: formData });
        const data = await res.json();
        stopLoading();
        if (data.status === 'ok') {
            notify('Import dữ liệu SQL thành công!');
            fileInput.value = '';
            textInput.value = '';
            await switchMySQLDatabase(currentSqlDb);
            switchPmaTab('structure');
        } else {
            notify(data.message || 'Lỗi Import SQL!', 'error');
        }
    } catch (e) {
        stopLoading();
        notify('Lỗi kết nối khi Import SQL!', 'error');
    }
}

function toggleSelectItem(rel, checked) {
    checked ? selectedPaths.add(rel) : selectedPaths.delete(rel);
    updateBulkBar();
}

function toggleSelectAll(checked) {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = checked);
    selectedPaths.clear();
    if (checked) currentItems.forEach(i => selectedPaths.add(i.rel));
    updateBulkBar();
}

function updateBulkBar() {
    const bar = document.getElementById('bulkBar');
    if (selectedPaths.size > 0) {
        bar.classList.remove('hidden');
        bar.classList.add('flex');
        document.getElementById('selectedCount').textContent = `${selectedPaths.size} mục`;
    } else {
        bar.classList.add('hidden');
        bar.classList.remove('flex');
    }
}

function toggleTheme() {
    const html = document.documentElement;
    html.classList.toggle('dark');
    const isDark = html.classList.contains('dark');
    document.querySelectorAll('.themeIconCls').forEach(icon => {
        icon.className = isDark ? 'themeIconCls fa-solid fa-moon' : 'themeIconCls fa-solid fa-sun text-amber-500';
    });
    if (aceInstance) aceInstance.setTheme(isDark ? "ace/theme/one_dark" : "ace/theme/chrome");
}

function formatSize(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDate(ts) {
    if (!ts) return '—';
    const d = new Date(ts * 1000);
    return d.toLocaleDateString('vi-VN') + ' ' + d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[m]);
}

function escapeQuotes(str) {
    return String(str).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}