<?php
/**
 * DONGM Workspace v6.0 - Module 1: Configuration
 * Crafted by Đặng Minh Đông
 */
session_start();
error_reporting(0);
@ini_set('display_errors', '0');
@set_time_limit(600);
date_default_timezone_set('Asia/Ho_Chi_Minh');

// ================= CẤU HÌNH HỆ THỐNG =================
$APP_VERSION      = 'v6.0';                  // Phiên bản Modular 6.0
$AUTH_PASSWORD    = '3664';                 // ĐỔI MẬT KHẨU CỦA BẠN TẠI ĐÂY
$ROOT_DIR         = dirname(__DIR__);        // Quản lý thư mục cha (public_html) chứa thư mục dongm
$PROTECT_SELF_DIR = true;                    // Khóa bảo vệ thư mục /dongm khỏi bị xóa nhầm
$MAX_UPLOAD_SIZE  = 500 * 1024 * 1024;       // Giới hạn tải lên 500MB (Chunked Upload)
// =====================================================

$DONGM_DIR_NAME = basename(__DIR__);
$DATA_DIR       = __DIR__ . DIRECTORY_SEPARATOR . 'data';
$LOG_FILE       = $DATA_DIR . DIRECTORY_SEPARATOR . 'auth_logs.json';

// Tự động tạo thư mục data/ và .htaccess chặn truy cập trực tiếp từ bên ngoài
if (!is_dir($DATA_DIR)) {
    @mkdir($DATA_DIR, 0755, true);
}
if (is_dir($DATA_DIR) && !file_exists($DATA_DIR . DIRECTORY_SEPARATOR . '.htaccess')) {
    @file_put_contents($DATA_DIR . DIRECTORY_SEPARATOR . '.htaccess', "Order deny,allow\nDeny from all\n");
}
if (is_dir($DATA_DIR) && !file_exists($LOG_FILE)) {
    @file_put_contents($LOG_FILE, json_encode([]));
}