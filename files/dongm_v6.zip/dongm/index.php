<?php
/**
 * DONGM Workspace v6.0 - Module 4: Main UI & Auth Gate
 * Crafted by Đặng Minh Đông
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/core.php';

// Chuyển hướng nếu gọi ?api=... hoặc ?download=... vào thẳng api.php
if (isset($_GET['api']) || isset($_GET['download']) || isset($_GET['preview']) || isset($_GET['mysql_export'])) {
    require_once __DIR__ . '/api.php';
    exit;
}

// Xử lý Đăng xuất
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// Xử lý Đăng nhập & Ghi Lịch Sử Đăng Nhập
if (isset($_POST['auth_pass'])) {
    if ($_POST['auth_pass'] === $AUTH_PASSWORD) {
        $_SESSION['dongm_auth'] = true;
        record_login_log(true);
        header("Location: index.php");
        exit;
    } else {
        record_login_log(false);
        $login_error = "Mật khẩu xác thực không chính xác!";
    }
}

// Giao diện Đăng nhập
if (empty($_SESSION['dongm_auth'])):
?>
<!DOCTYPE html>
<html lang="vi" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Đăng nhập — DONGM Manager <?php echo htmlspecialchars($APP_VERSION); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=<?php echo urlencode($APP_VERSION); ?>">
</head>
<body class="bg-[#060911] text-slate-100 min-h-screen flex flex-col justify-between p-4 selection:bg-indigo-500 selection:text-white relative overflow-hidden">
    <div class="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-fuchsia-600/15 rounded-full blur-3xl pointer-events-none"></div>

    <div></div>
    <div class="w-full max-w-sm mx-auto bg-slate-900/80 border border-slate-800/90 rounded-3xl shadow-2xl p-7 sm:p-8 backdrop-blur-2xl relative z-10">
        <div class="flex flex-col items-center mb-6">
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl mb-3.5 shadow-xl shadow-indigo-500/30 ring-4 ring-indigo-500/10">
                <i class="fa-solid fa-bolt"></i>
            </div>
            <div class="flex items-center gap-2">
                <h1 class="text-xl font-extrabold tracking-tight">DONGM Workspace</h1>
                <span class="text-[11px] px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 font-extrabold font-mono"><?php echo htmlspecialchars($APP_VERSION); ?></span>
            </div>
            <p class="text-xs text-slate-400 mt-1">Modular Cloud File & phpMyAdmin Suite</p>
        </div>
        <?php if (!empty($login_error)): ?>
            <div class="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/25 text-rose-400 text-xs font-medium flex items-center gap-2">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span><?php echo htmlspecialchars($login_error); ?></span>
            </div>
        <?php endif; ?>
        <form method="POST" class="space-y-4">
            <div class="relative">
                <i class="fa-solid fa-key absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xs"></i>
                <input type="password" name="auth_pass" placeholder="Nhập mật khẩu quản trị..." required autofocus
                    class="w-full pl-10 pr-4 py-3 bg-slate-950/90 border border-slate-800 rounded-2xl text-xs sm:text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
            </div>
            <button type="submit" class="w-full py-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:opacity-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2">
                <span>Truy cập Hệ thống</span>
                <i class="fa-solid fa-arrow-right text-xs"></i>
            </button>
        </form>
    </div>

    <footer class="text-center text-xs text-slate-500 py-3 relative z-10">
        Crafted with <i class="fa-solid fa-heart text-rose-500 mx-0.5"></i> by <span class="text-slate-300 font-bold">Đặng Minh Đông</span>
        <span class="ml-1.5 px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono text-[11px] font-bold"><?php echo htmlspecialchars($APP_VERSION); ?></span>
    </footer>
</body>
</html>
<?php
exit;
endif;
?>
<!DOCTYPE html>
<html lang="vi" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>DONGM Manager <?php echo htmlspecialchars($APP_VERSION); ?> — Modular Workspace</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: {} } }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=<?php echo urlencode($APP_VERSION); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/ace.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/theme-one_dark.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/theme-chrome.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/mode-php.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/mode-javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/mode-html.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/mode-css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.6/mode-json.min.js"></script>
</head>
<body class="bg-slate-100 dark:bg-[#060911] text-slate-800 dark:text-slate-100 min-h-screen flex flex-col selection:bg-indigo-500 selection:text-white transition-colors duration-200 relative">

    <div class="fixed -top-48 left-1/4 w-[500px] h-[300px] bg-indigo-600/10 rounded-full blur-[130px] pointer-events-none hidden dark:block"></div>
    <div class="fixed bottom-0 right-10 w-[420px] h-[280px] bg-purple-600/10 rounded-full blur-[130px] pointer-events-none hidden dark:block"></div>

    <!-- Thanh Loading Top Progress Bar & Badge -->
    <div id="topLoadingContainer" class="fixed top-0 left-0 right-0 z-[100] h-1 pointer-events-none overflow-hidden opacity-0 transition-opacity duration-200">
        <div id="topLoadingBar" class="h-full w-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 transition-all duration-200 ease-out"></div>
    </div>
    <div id="loadingPill" class="fixed top-14 right-3 sm:right-5 z-40 hidden items-center gap-2 px-3 py-1 rounded-full bg-slate-900/95 dark:bg-slate-800/95 text-white border border-indigo-500/30 shadow-lg text-[11px] font-semibold backdrop-blur-md pointer-events-none">
        <i class="fa-solid fa-circle-notch fa-spin text-indigo-400"></i>
        <span id="loadingPillText">Đang xử lý...</span>
    </div>

    <!-- Top Header -->
    <header class="sticky top-0 z-30 bg-white/90 dark:bg-[#0b101d]/90 backdrop-blur-xl border-b border-slate-200/80 dark:border-slate-800/80 px-3 sm:px-5 py-2.5 shadow-sm">
        <div class="max-w-[1640px] mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5">
            <div class="flex items-center justify-between gap-2">
                <div onclick="loadDir('')" class="cursor-pointer flex items-center gap-2.5 group min-w-0">
                    <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white text-sm sm:text-base shadow-lg shadow-indigo-500/25 shrink-0 group-hover:scale-105 transition">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="font-extrabold text-sm sm:text-[15px] leading-tight tracking-tight flex items-center gap-1.5">
                            <span class="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">DONGM</span>
                            <span>MANAGER</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 font-mono font-bold"><?php echo htmlspecialchars($APP_VERSION); ?></span>
                        </div>
                        <div class="text-[11px] text-slate-400 truncate">Modular Edition • Smart Chunked Upload</div>
                    </div>
                </div>

                <!-- Cụm nút trên Mobile -->
                <div class="flex items-center gap-1 sm:hidden">
                    <button onclick="openUploadModal()" class="px-2.5 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                        <span>Upload</span>
                    </button>
                    <button onclick="openActionModal('mkfile')" class="w-8 h-8 bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs flex items-center justify-center text-emerald-500" title="Tạo tệp mới">
                        <i class="fa-solid fa-file-circle-plus"></i>
                    </button>
                    <button onclick="openActionModal('mkdir')" class="w-8 h-8 bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs flex items-center justify-center text-amber-500" title="Tạo thư mục mới">
                        <i class="fa-solid fa-folder-plus"></i>
                    </button>
                    <button onclick="toggleSound()" class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 flex items-center justify-center text-xs text-indigo-500">
                        <i class="soundIconCls fa-solid fa-volume-high"></i>
                    </button>
                    <button onclick="toggleTheme()" class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 flex items-center justify-center text-xs">
                        <i class="themeIconCls fa-solid fa-moon"></i>
                    </button>
                    <a href="?logout=1" class="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-center text-xs" title="Đăng xuất">
                        <i class="fa-solid fa-power-off"></i>
                    </a>
                </div>
            </div>

            <!-- Hàng 2 trên Mobile / Bên phải trên PC -->
            <div class="flex items-center gap-2 w-full sm:w-auto justify-end">
                <div class="relative flex-1 sm:w-60 md:w-64">
                    <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
                    <input id="searchInput" type="text" placeholder="Lọc nhanh tệp & thư mục (/)..." oninput="renderTable()"
                        class="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-xl focus:outline-none focus:border-indigo-500 transition">
                </div>

                <button onclick="loadDir(currentPath, true)" class="sm:hidden w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-xs shrink-0" title="Làm mới">
                    <i class="refreshIconCls fa-solid fa-rotate"></i>
                </button>

                <!-- Cụm nút trên PC -->
                <div class="hidden sm:flex items-center gap-1.5">
                    <button onclick="openUploadModal()" class="px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-500/20 transition">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                        <span>Tải lên (Chunked)</span>
                    </button>
                    <button onclick="openActionModal('mkfile')" class="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 hover:border-emerald-500/50 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition">
                        <i class="fa-solid fa-file-circle-plus text-emerald-500"></i>
                        <span class="hidden md:inline">+Tệp</span>
                    </button>
                    <button onclick="openActionModal('mkdir')" class="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 hover:border-amber-500/50 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition">
                        <i class="fa-solid fa-folder-plus text-amber-500"></i>
                        <span class="hidden md:inline">+Thư mục</span>
                    </button>
                    <button onclick="loadDir(currentPath, true)" class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 hover:text-indigo-500 flex items-center justify-center text-xs transition" title="Làm mới danh sách">
                        <i class="refreshIconCls fa-solid fa-rotate"></i>
                    </button>
                    <button onclick="toggleSound()" class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-indigo-500 flex items-center justify-center text-xs transition" title="Bật/Tắt âm thanh">
                        <i class="soundIconCls fa-solid fa-volume-high"></i>
                    </button>
                    <button onclick="toggleTheme()" class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 flex items-center justify-center text-xs transition" title="Đổi giao diện Sáng/Tối">
                        <i class="themeIconCls fa-solid fa-moon"></i>
                    </button>
                    <a href="?logout=1" class="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500 hover:text-white text-rose-500 flex items-center justify-center text-xs transition" title="Đăng xuất">
                        <i class="fa-solid fa-power-off"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main 2-Column Workspace -->
    <main class="max-w-[1640px] w-full mx-auto flex-1 px-2.5 sm:px-5 py-3.5 sm:py-4 grid grid-cols-1 lg:grid-cols-12 gap-4 items-start relative z-10">

        <!-- CỘT TRÁI (8/12): DANH SÁCH QUẢN LÝ FILE -->
        <section class="lg:col-span-8 xl:col-span-9 flex flex-col gap-3 min-w-0 w-full">

            <!-- Thanh Breadcrumb + Clipboard + Bulk Actions -->
            <div class="flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-[#0d1322]/95 border border-slate-200/80 dark:border-slate-800/90 rounded-2xl px-3 sm:px-4 py-2.5 shadow-sm">
                <div class="flex items-center gap-1.5 min-w-0 flex-1">
                    <nav id="breadcrumb" class="flex items-center gap-1 text-xs overflow-x-auto no-scrollbar max-w-full py-0.5"></nav>
                    <button onclick="copyCurrentPath()" class="w-7 h-7 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-400 flex items-center justify-center text-xs shrink-0 transition" title="Sao chép đường dẫn hiện tại">
                        <i class="fa-regular fa-copy"></i>
                    </button>
                </div>

                <div class="flex items-center gap-1.5 flex-wrap">
                    <div id="clipboardBar" class="hidden items-center gap-1.5 bg-indigo-500/10 border border-indigo-500/25 px-2.5 py-1 rounded-xl">
                        <span id="clipboardInfo" class="text-[11px] font-bold text-indigo-400"></span>
                        <button onclick="pasteClipboard()" class="px-2 py-0.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold transition">
                            <i class="fa-solid fa-paste mr-1"></i>Dán vào đây
                        </button>
                        <button onclick="clearClipboard()" class="text-slate-400 hover:text-rose-400 text-xs px-1" title="Hủy bộ nhớ tạm">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <div id="bulkBar" class="hidden items-center gap-1.5 flex-wrap">
                        <span id="selectedCount" class="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/25"></span>
                        <button onclick="setClipboard('copy')" class="px-2.5 py-1 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 text-xs font-semibold flex items-center gap-1 transition" title="Sao chép">
                            <i class="fa-regular fa-copy"></i> <span class="hidden sm:inline">Chép</span>
                        </button>
                        <button onclick="setClipboard('cut')" class="px-2.5 py-1 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 text-xs font-semibold flex items-center gap-1 transition" title="Di chuyển">
                            <i class="fa-solid fa-scissors"></i> <span class="hidden sm:inline">Cắt</span>
                        </button>
                        <button onclick="openZipModal()" class="px-2.5 py-1 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-semibold flex items-center gap-1 transition">
                            <i class="fa-solid fa-file-zipper"></i> Nén ZIP
                        </button>
                        <button onclick="bulkDelete()" class="px-2.5 py-1 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold flex items-center gap-1 transition">
                            <i class="fa-solid fa-trash-can"></i> Xóa
                        </button>
                    </div>
                </div>
            </div>

            <!-- Bảng danh sách tệp -->
            <div id="fileTableCard" class="bg-white dark:bg-[#0d1322]/95 border border-slate-200/80 dark:border-slate-800/90 rounded-2xl shadow-sm overflow-hidden flex flex-col transition-opacity duration-150 w-full">
                <div class="w-full overflow-x-auto">
                    <table class="w-full text-left border-collapse table-fixed sm:table-auto">
                        <thead>
                            <tr class="border-b border-slate-200/80 dark:border-slate-800/90 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/80 dark:bg-slate-950/60 select-none">
                                <th class="py-3 pl-3 sm:pl-4 pr-1.5 w-9">
                                    <input id="checkAll" type="checkbox" onchange="toggleSelectAll(this.checked)" class="w-3.5 h-3.5 rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer">
                                </th>
                                <th onclick="changeSort('name')" class="py-3 px-2 cursor-pointer hover:text-indigo-400 transition">
                                    <div class="flex items-center gap-1.5">
                                        <span>Tên tệp / Thư mục</span>
                                        <i id="sortIcon_name" class="fa-solid fa-arrow-up-a-z text-indigo-400 text-[10px]"></i>
                                    </div>
                                </th>
                                <th onclick="changeSort('size')" class="py-3 px-3 hidden sm:table-cell w-28 cursor-pointer hover:text-indigo-400 transition">
                                    <div class="flex items-center gap-1">
                                        <span>Kích thước</span>
                                        <i id="sortIcon_size" class="fa-solid fa-sort text-[10px] opacity-40"></i>
                                    </div>
                                </th>
                                <th class="py-3 px-2.5 hidden md:table-cell w-20">Quyền</th>
                                <th onclick="changeSort('mtime')" class="py-3 px-2.5 hidden xl:table-cell w-36 cursor-pointer hover:text-indigo-400 transition">
                                    <div class="flex items-center gap-1">
                                        <span>Sửa đổi</span>
                                        <i id="sortIcon_mtime" class="fa-solid fa-sort text-[10px] opacity-40"></i>
                                    </div>
                                </th>
                                <th class="py-3 pl-1 pr-3 sm:pr-4 text-right w-32 sm:w-44">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody id="fileListBody" class="divide-y divide-slate-200/60 dark:divide-slate-800/60 text-xs sm:text-[13.5px]"></tbody>
                    </table>
                </div>

                <!-- Footer bảng: Thống kê số mục + Tính tổng dung lượng thư mục hiện tại -->
                <div class="px-3.5 sm:px-4 py-2.5 bg-slate-50/70 dark:bg-slate-950/50 border-t border-slate-200/70 dark:border-slate-800/80 text-[11px] sm:text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2">
                    <span id="itemSummary" class="font-semibold text-slate-500 dark:text-slate-400">Đang tải dữ liệu...</span>
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-chart-pie text-indigo-400"></i>
                            <span>Tổng dung lượng thư mục: <strong id="currentFolderSize" class="text-slate-700 dark:text-slate-200 font-mono">0 B</strong></span>
                        </span>
                        <button id="deepSizeBtn" onclick="calculateDeepFolderSize()" class="px-2.5 py-0.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 text-[11px] font-bold transition flex items-center gap-1" title="Quét đệ quy bao gồm toàn bộ các thư mục con">
                            <i class="fa-solid fa-calculator text-[10px]"></i>
                            <span>Tính sâu (+Thư mục con)</span>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- CỘT PHẢI (4/12): 2 TAB CHUYỂN ĐỔI (THÔNG TIN & MYSQL) -->
        <aside class="lg:col-span-4 xl:col-span-3 flex flex-col w-full min-w-0">
            <div class="bg-white dark:bg-[#0d1322]/95 border border-slate-200/80 dark:border-slate-800/90 rounded-2xl shadow-sm overflow-hidden flex flex-col">

                <!-- Thanh chuyển đổi 2 Tab -->
                <div class="grid grid-cols-2 p-1.5 bg-slate-100/90 dark:bg-slate-950/80 border-b border-slate-200/80 dark:border-slate-800 gap-1.5">
                    <button id="tabBtnInfo" onclick="switchRightTab('info')" class="py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all bg-white dark:bg-slate-800 text-indigo-500 shadow-sm">
                        <i class="fa-solid fa-server"></i>
                        <span>Thông tin</span>
                    </button>
                    <button id="tabBtnSql" onclick="switchRightTab('sql')" class="py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all text-slate-500 hover:text-slate-800 dark:hover:text-slate-200">
                        <i class="fa-solid fa-database"></i>
                        <span>MySQL</span>
                        <span id="sqlBadgeDot" class="hidden w-2 h-2 rounded-full bg-emerald-500"></span>
                    </button>
                </div>

                <!-- NỘI DUNG TAB 1: THÔNG TIN + LỊCH SỬ ĐĂNG NHẬP -->
                <div id="tabPaneInfo" class="p-3.5 space-y-3.5">
                    <div class="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent border border-indigo-500/20">
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-sm">
                                    <i class="fa-solid fa-hard-drive"></i>
                                </div>
                                <div>
                                    <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Dung lượng Đĩa</div>
                                    <div id="diskSubText" class="text-[11px] text-slate-400">Đang tính toán...</div>
                                </div>
                            </div>
                            <span id="diskPercentBadge" class="text-[11px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">0%</span>
                        </div>

                        <div class="w-full bg-slate-200 dark:bg-slate-800/90 h-2 rounded-full overflow-hidden my-2.5">
                            <div id="diskBar" class="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 h-full w-0 transition-all duration-500"></div>
                        </div>

                        <div class="grid grid-cols-3 gap-1.5 text-center">
                            <div class="bg-white/80 dark:bg-slate-900/90 p-2 rounded-xl border border-slate-200/60 dark:border-slate-800">
                                <div class="text-[10px] text-slate-400">Đã dùng</div>
                                <div id="diskUsed" class="text-xs font-bold font-mono mt-0.5">—</div>
                            </div>
                            <div class="bg-white/80 dark:bg-slate-900/90 p-2 rounded-xl border border-slate-200/60 dark:border-slate-800">
                                <div class="text-[10px] text-slate-400">Còn trống</div>
                                <div id="diskFree" class="text-xs font-bold font-mono text-emerald-400 mt-0.5">—</div>
                            </div>
                            <div class="bg-white/80 dark:bg-slate-900/90 p-2 rounded-xl border border-slate-200/60 dark:border-slate-800">
                                <div class="text-[10px] text-slate-400">Tổng Đĩa</div>
                                <div id="diskTotal" class="text-xs font-bold font-mono mt-0.5">—</div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-2">
                        <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 flex items-center gap-2 min-w-0">
                            <div class="w-7 h-7 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center text-xs shrink-0">
                                <i class="fa-solid fa-network-wired"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-[10px] text-slate-400">IP Server</div>
                                <div id="srvIp" class="text-xs font-mono font-bold text-sky-400 truncate">—</div>
                            </div>
                        </div>

                        <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 flex items-center gap-2 min-w-0">
                            <div class="w-7 h-7 rounded-lg bg-purple-500/15 text-purple-400 flex items-center justify-center text-xs shrink-0">
                                <i class="fa-solid fa-user-shield"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-[10px] text-slate-400">IP Của bạn</div>
                                <div id="clientIp" class="text-xs font-mono font-bold truncate">—</div>
                            </div>
                        </div>

                        <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 flex items-center gap-2 min-w-0">
                            <div class="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center text-xs shrink-0">
                                <i class="fa-brands fa-php text-sm"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-[10px] text-slate-400">PHP Version</div>
                                <div id="srvPhp" class="text-xs font-mono font-bold text-emerald-400 truncate">—</div>
                            </div>
                        </div>

                        <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 flex items-center gap-2 min-w-0">
                            <div class="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center text-xs shrink-0">
                                <i class="fa-solid fa-cubes-stacked"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-[10px] text-slate-400">Host / Chunk</div>
                                <div id="srvUploadIni" class="text-xs font-mono font-bold text-amber-400 truncate">—</div>
                            </div>
                        </div>
                    </div>

                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 space-y-2 text-xs">
                        <div class="flex items-center justify-between gap-2">
                            <span class="text-slate-400 flex items-center gap-1.5 shrink-0"><i class="fa-solid fa-cubes text-indigo-400"></i> Web Server:</span>
                            <span id="srvSoft" class="font-semibold text-right truncate" title="">—</span>
                        </div>
                        <div class="border-t border-slate-200/60 dark:border-slate-800/80"></div>
                        <div class="flex items-center justify-between gap-2">
                            <span class="text-slate-400 flex items-center gap-1.5 shrink-0"><i class="fa-brands fa-linux text-pink-400"></i> Hệ điều hành:</span>
                            <span id="srvOs" class="font-semibold text-right truncate" title="">—</span>
                        </div>
                    </div>

                    <!-- Tiện ích PHP (Extensions) -->
                    <div>
                        <div class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-puzzle-piece text-indigo-400"></i> Tiện ích PHP (Extensions)
                        </div>
                        <div id="srvExts" class="grid grid-cols-2 gap-1.5 text-xs"></div>
                    </div>

                    <!-- KHUNG LỊCH SỬ ĐĂNG NHẬP (MỚI BỔ SUNG NGAY DƯỚI EXTENSIONS) -->
                    <div class="pt-1 border-t border-slate-200/70 dark:border-slate-800/80">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                                <i class="fa-solid fa-clock-rotate-left text-emerald-400"></i> Lịch sử đăng nhập
                            </div>
                            <button onclick="clearLoginHistory()" class="text-[10px] px-2 py-0.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-semibold transition" title="Xóa lịch sử đăng nhập">
                                Xóa log
                            </button>
                        </div>
                        <div id="loginHistoryList" class="max-h-48 overflow-y-auto space-y-1.5 pr-0.5">
                            <div class="text-[11px] text-slate-400 text-center py-3">Đang tải lịch sử...</div>
                        </div>
                    </div>
                </div>

                <!-- NỘI DUNG TAB 2: TRÌNH QUẢN LÝ MYSQL -->
                <div id="tabPaneSql" class="hidden p-3.5 space-y-3">
                    <div id="sqlLoginBox" class="space-y-2.5">
                        <div class="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-[11px] text-indigo-300 leading-relaxed flex items-start gap-2">
                            <i class="fa-solid fa-circle-info mt-0.5"></i>
                            <span>Phiên kết nối MySQL tự động lưu lại trên cả Server & Trình duyệt.</span>
                        </div>
                        <div class="grid grid-cols-3 gap-2">
                            <div class="col-span-2">
                                <label class="text-[11px] text-slate-400 block mb-1">MySQL Host</label>
                                <input id="dbHost" type="text" value="localhost" class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                            </div>
                            <div>
                                <label class="text-[11px] text-slate-400 block mb-1">Port</label>
                                <input id="dbPort" type="number" value="3306" class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                            </div>
                        </div>
                        <div>
                            <label class="text-[11px] text-slate-400 block mb-1">Username</label>
                            <input id="dbUser" type="text" placeholder="root / tên_user_db" class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="text-[11px] text-slate-400 block mb-1">Password</label>
                            <input id="dbPass" type="password" placeholder="Mật khẩu Database..." class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                        </div>
                        <div>
                            <label class="text-[11px] text-slate-400 block mb-1">Database Name (Tùy chọn)</label>
                            <input id="dbName" type="text" placeholder="Để trống sẽ tự liệt kê..." class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                        </div>
                        <button onclick="connectMySQL()" class="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl text-xs transition shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2">
                            <i class="fa-solid fa-plug"></i> Kết nối & Lưu phiên MySQL
                        </button>
                    </div>

                    <div id="sqlConnectedBox" class="hidden space-y-3">
                        <div class="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
                            <div class="min-w-0">
                                <div class="text-[11px] text-emerald-400 font-bold flex items-center gap-1.5">
                                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span> Đã lưu phiên MySQL
                                </div>
                                <div id="sqlConnSummary" class="text-[11px] text-slate-400 truncate mt-0.5 font-mono"></div>
                            </div>
                            <button onclick="disconnectMySQL()" class="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-400 hover:text-white text-[11px] font-semibold transition">
                                Thoát DB
                            </button>
                        </div>

                        <div>
                            <label class="text-[11px] text-slate-400 block mb-1 font-medium">Cơ sở dữ liệu (Database):</label>
                            <select id="sqlDbSelect" onchange="switchMySQLDatabase(this.value)" class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 font-semibold"></select>
                        </div>

                        <div class="grid grid-cols-2 gap-1.5">
                            <button onclick="openSqlModal('', 'browse')" class="col-span-2 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl text-xs transition shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2">
                                <i class="fa-solid fa-table-columns"></i> Mở cửa sổ phpMyAdmin
                            </button>
                            <button onclick="openSqlModal('', 'export')" class="py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/25 text-emerald-400 font-semibold rounded-xl text-xs transition flex items-center justify-center gap-1.5">
                                <i class="fa-solid fa-file-export"></i> Xuất (.SQL)
                            </button>
                            <button onclick="openSqlModal('', 'import')" class="py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/25 text-amber-400 font-semibold rounded-xl text-xs transition flex items-center justify-center gap-1.5">
                                <i class="fa-solid fa-file-import"></i> Nhập (.SQL)
                            </button>
                        </div>

                        <div>
                            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1 font-medium">
                                <span>Danh sách Bảng:</span>
                                <span id="sqlTableCount" class="font-bold text-indigo-400">0 bảng</span>
                            </div>
                            <div id="sqlTableList" class="max-h-64 overflow-y-auto divide-y divide-slate-200/60 dark:divide-slate-800/60 border border-slate-200/80 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40"></div>
                        </div>
                    </div>
                </div>

            </div>
        </aside>
    </main>

    <!-- Footer Bản Quyền + Phiên Bản v6.0 + Đo Độ Trễ (Ping) -->
    <footer class="mt-auto border-t border-slate-200/80 dark:border-slate-800/80 bg-white/75 dark:bg-[#0b101d]/80 backdrop-blur-md py-3 px-3 sm:px-5 relative z-10">
        <div class="max-w-[1640px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <div class="flex items-center gap-2.5 flex-wrap justify-center">
                <div class="flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>Modular Engine: <strong>500MB Chunked Ready</strong></span>
                </div>
                <span class="text-slate-300 dark:text-slate-700">|</span>
                <button onclick="measurePing()" class="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800/90 hover:bg-indigo-500/10 border border-slate-200 dark:border-slate-700/80 transition cursor-pointer" title="Nhấn để đo lại độ trễ phản hồi Server">
                    <i class="fa-solid fa-signal text-[10px] text-indigo-400"></i>
                    <span>Độ trễ (Ping): <strong id="pingValue" class="text-emerald-400 font-mono">-- ms</strong></span>
                </button>
            </div>
            <div class="flex items-center gap-1.5 flex-wrap justify-center text-center">
                <span>© <?php echo date('Y'); ?> <strong>DONGM File Manager</strong> — Bản quyền bởi</span>
                <span class="font-extrabold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">Đặng Minh Đông</span>
                <span class="px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 font-mono text-[11px] font-extrabold"><?php echo htmlspecialchars($APP_VERSION); ?></span>
            </div>
        </div>
    </footer>

    <!-- ================= CÁC MODAL CHỨC NĂNG ================= -->
    <div id="actionModal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-sm p-4 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                    <div id="actionModalIconBox" class="w-9 h-9 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center text-base">
                        <i id="actionModalIcon" class="fa-solid fa-file-circle-plus"></i>
                    </div>
                    <div>
                        <h3 id="actionModalTitle" class="font-bold text-sm">Tạo tệp tin mới</h3>
                        <p id="actionModalSub" class="text-[11px] text-slate-400">Kiểm tra trùng tên tự động theo thời gian thực</p>
                    </div>
                </div>
                <button onclick="closeActionModal()" class="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div>
                <input id="actionModalInput" type="text" oninput="validateActionModalInput()" class="w-full px-3.5 py-2.5 text-xs sm:text-sm font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 transition">
                <p id="actionModalDupWarn" class="hidden mt-2 text-[11px] text-amber-400 font-medium flex items-center gap-1.5">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <span id="actionModalDupText">Tên này đã tồn tại trong thư mục hiện tại!</span>
                </p>
                <div id="chmodPresets" class="hidden mt-2.5 flex items-center gap-1.5 flex-wrap">
                    <span class="text-[11px] text-slate-400 mr-1">Chọn nhanh:</span>
                    <button type="button" onclick="setActionInputVal('0644')" class="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-500/20 text-xs font-mono">0644 (File chuẩn)</button>
                    <button type="button" onclick="setActionInputVal('0755')" class="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-500/20 text-xs font-mono">0755 (Thư mục chuẩn)</button>
                    <button type="button" onclick="setActionInputVal('0777')" class="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-500/20 text-xs font-mono">0777 (Full quyền)</button>
                </div>
            </div>

            <div class="flex justify-end gap-2 pt-1">
                <button onclick="closeActionModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-semibold">Hủy</button>
                <button id="actionModalSubmitBtn" onclick="submitActionModal()" class="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-md">Xác nhận</button>
            </div>
        </div>
    </div>

    <!-- Modal Nén ZIP -->
    <div id="zipBuilderModal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-sm p-4 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center text-base">
                        <i class="fa-solid fa-file-zipper"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-sm">Đóng gói & Nén ZIP Pro</h3>
                        <p id="zipBuilderCountInfo" class="text-[11px] text-slate-400">Đã chọn 0 mục</p>
                    </div>
                </div>
                <button onclick="closeZipModal()" class="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div class="space-y-3">
                <div>
                    <label class="text-xs text-slate-400 block mb-1 font-medium">Tên tệp tin ZIP (Tự động gắn giờ & ngày):</label>
                    <input id="zipNameInput" type="text" oninput="checkZipDuplicateLive()" class="w-full px-3 py-2 text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500">
                    <p id="zipDupWarn" class="hidden mt-1.5 text-[11px] text-amber-400 flex items-center gap-1.5">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                        <span>Cảnh báo: Tên tệp ZIP này đã tồn tại (Sẽ ghi đè nếu tiếp tục)!</span>
                    </p>
                </div>

                <div>
                    <label class="text-xs text-slate-400 block mb-1 font-medium">Cấp độ nén (Compression Level):</label>
                    <select id="zipLevelSelect" class="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 font-semibold">
                        <option value="9">Nén tối đa (Level 9 — Tiết kiệm dung lượng nhất)</option>
                        <option value="6" selected>Nén tiêu chuẩn (Level 6 — Cân bằng tốc độ & dung lượng)</option>
                        <option value="0">Nén siêu tốc (Level 0 — Đóng gói trực tiếp, 0 độ trễ)</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-end gap-2 pt-1">
                <button onclick="closeZipModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-semibold">Hủy</button>
                <button onclick="confirmZipCreation()" class="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-xs font-bold shadow-md flex items-center gap-1.5">
                    <i class="fa-solid fa-bolt"></i> Bắt đầu Nén
                </button>
            </div>
        </div>
    </div>

    <!-- Modal Xem trước ZIP -->
    <div id="zipPreviewModal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-sm p-2 sm:p-4 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div class="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50 dark:bg-slate-900">
                <div class="flex items-center gap-2.5 min-w-0">
                    <div class="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center text-sm shrink-0">
                        <i class="fa-solid fa-file-zipper"></i>
                    </div>
                    <div class="min-w-0">
                        <h3 id="zipPreviewTitle" class="font-bold text-xs sm:text-sm truncate">Xem trước gói ZIP</h3>
                        <p id="zipPreviewMeta" class="text-[11px] text-slate-400 truncate"></p>
                    </div>
                </div>
                <div class="flex items-center gap-1.5 shrink-0">
                    <button id="zipPreviewExtractBtn" class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm">
                        <i class="fa-solid fa-box-open"></i> <span>Giải nén ngay</span>
                    </button>
                    <button onclick="closeZipPreviewModal()" class="w-8 h-8 rounded-xl bg-slate-200/70 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
            </div>
            <div class="flex-1 overflow-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 dark:border-slate-800 text-[11px] uppercase text-slate-400 bg-slate-50/70 dark:bg-slate-950/50 sticky top-0">
                            <th class="py-2 px-3">Tên tệp trong ZIP</th>
                            <th class="py-2 px-2.5 w-24 hidden sm:table-cell">Gốc</th>
                            <th class="py-2 px-2.5 w-24">Nén</th>
                            <th class="py-2 px-3 w-32 text-right hidden md:table-cell">Ngày sửa</th>
                        </tr>
                    </thead>
                    <tbody id="zipPreviewBody" class="divide-y divide-slate-200/60 dark:divide-slate-800/60 font-mono text-[11px]"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal phpMyAdmin Suite -->
    <div id="sqlModal" class="fixed inset-0 z-50 hidden bg-slate-950/85 backdrop-blur-sm p-0 sm:p-3 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border-0 sm:border border-slate-200 dark:border-slate-800 rounded-none sm:rounded-3xl w-full max-w-[1500px] h-[100dvh] sm:h-[92vh] flex flex-col shadow-2xl overflow-hidden">

            <div class="px-3.5 sm:px-5 py-2.5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-50 dark:bg-slate-950/60">
                <div class="flex items-center gap-2 min-w-0">
                    <div class="w-8 h-8 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center text-sm shrink-0">
                        <i class="fa-solid fa-database"></i>
                    </div>
                    <span class="font-extrabold text-xs sm:text-sm truncate">phpMyAdmin</span>
                    <span id="sqlModalDbBadge" class="text-[11px] px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 font-mono font-bold truncate max-w-[110px] sm:max-w-none"></span>
                    <span id="sqlModalTableBadge" class="hidden text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-mono font-bold truncate max-w-[110px] sm:max-w-none"></span>
                </div>

                <div class="flex items-center gap-1 bg-slate-200/70 dark:bg-slate-800/80 p-1 rounded-xl overflow-x-auto no-scrollbar max-w-full order-3 lg:order-2 w-full lg:w-auto">
                    <button id="pmaTabBrowse" onclick="switchPmaTab('browse')" class="px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 bg-white dark:bg-slate-900 text-indigo-400 shadow-sm">
                        <i class="fa-solid fa-table"></i> Duyệt & Sửa
                    </button>
                    <button id="pmaTabStruct" onclick="switchPmaTab('structure')" class="px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 text-slate-400 hover:text-white">
                        <i class="fa-solid fa-sitemap"></i> Cấu trúc
                    </button>
                    <button id="pmaTabSql" onclick="switchPmaTab('sql')" class="px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 text-slate-400 hover:text-white">
                        <i class="fa-solid fa-terminal"></i> SQL
                    </button>
                    <button id="pmaTabExport" onclick="switchPmaTab('export')" class="px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 text-slate-400 hover:text-white">
                        <i class="fa-solid fa-file-export"></i> Xuất
                    </button>
                    <button id="pmaTabImport" onclick="switchPmaTab('import')" class="px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shrink-0 text-slate-400 hover:text-white">
                        <i class="fa-solid fa-file-import"></i> Nhập
                    </button>
                </div>

                <button onclick="closeSqlModal()" class="order-2 lg:order-3 w-8 h-8 rounded-xl bg-slate-200/70 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition shrink-0">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div id="pmaQueryBar" class="p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-950/80">
                <div class="flex flex-col sm:flex-row gap-2">
                    <textarea id="sqlQueryInput" rows="2" placeholder="Nhập câu lệnh SQL (VD: SELECT * FROM `users` LIMIT 50;)..."
                        class="flex-1 p-2.5 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 resize-y"></textarea>
                    <div class="flex sm:flex-col justify-between gap-1.5 shrink-0">
                        <button onclick="executeSqlQuery()" class="flex-1 sm:flex-initial px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-sm">
                            <i class="fa-solid fa-play text-[10px]"></i> Thực thi
                        </button>
                        <button id="btnInsertRow" onclick="openInsertRowModal()" class="hidden flex-1 sm:flex-initial px-3.5 py-2 bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-400 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition">
                            <i class="fa-solid fa-plus"></i> Thêm dòng
                        </button>
                    </div>
                </div>
                <div class="flex flex-wrap items-center justify-between mt-1.5 text-[11px] text-slate-400 gap-2">
                    <span id="sqlExecMeta" class="truncate">Mẹo: Nhấp đúp (hoặc bấm nút Sửa) vào dòng bất kỳ để sửa trực tiếp.</span>
                    <div class="flex items-center gap-2 font-mono text-[11px]">
                        <button onclick="setQuickSql('SHOW TABLE STATUS;')" class="hover:text-indigo-400">SHOW TABLES</button>
                        <span>•</span>
                        <button onclick="setQuickSql('SHOW PROCESSLIST;')" class="hover:text-indigo-400">PROCESSLIST</button>
                    </div>
                </div>
            </div>

            <div id="sqlResultContainer" class="flex-1 overflow-auto p-3 text-xs">
                <div class="h-full flex items-center justify-center text-slate-400">Chọn một bảng hoặc thực thi câu lệnh SQL để xem dữ liệu</div>
            </div>

            <div id="pmaExportPane" class="hidden flex-1 overflow-auto p-4 sm:p-6">
                <div class="max-w-xl mx-auto bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center text-lg shrink-0">
                            <i class="fa-solid fa-file-export"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-sm">Xuất cơ sở dữ liệu ra file .SQL</h4>
                            <p class="text-xs text-slate-400">Bao gồm cấu trúc bảng (CREATE TABLE) và dữ liệu (INSERT INTO)</p>
                        </div>
                    </div>
                    <div>
                        <label class="text-xs text-slate-400 block mb-1.5 font-semibold">Phạm vi xuất dữ liệu:</label>
                        <select id="exportTableSelect" class="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 font-medium">
                            <option value="">-- Toàn bộ các bảng trong Database hiện tại --</option>
                        </select>
                    </div>
                    <button onclick="triggerSqlExport()" class="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs sm:text-sm transition shadow-md flex items-center justify-center gap-2">
                        <i class="fa-solid fa-download"></i> Tải xuống bản sao lưu (.SQL)
                    </button>
                </div>
            </div>

            <div id="pmaImportPane" class="hidden flex-1 overflow-auto p-4 sm:p-6">
                <div class="max-w-2xl mx-auto bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center text-lg shrink-0">
                            <i class="fa-solid fa-file-import"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-sm">Nhập dữ liệu từ file .SQL hoặc mã SQL</h4>
                            <p class="text-xs text-slate-400">Hỗ trợ thực thi hàng loạt câu lệnh (Multi-query Import)</p>
                        </div>
                    </div>
                    <div>
                        <label class="text-xs text-slate-400 block mb-1 font-semibold">Cách 1: Chọn file .sql từ thiết bị</label>
                        <input id="importSqlFile" type="file" accept=".sql,.txt" class="w-full text-xs file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-1.5">
                    </div>
                    <div>
                        <label class="text-xs text-slate-400 block mb-1 font-semibold">Cách 2: Hoặc dán trực tiếp nội dung SQL</label>
                        <textarea id="importSqlText" rows="6" placeholder="Dán nội dung file .sql vào đây..." class="w-full p-2.5 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500"></textarea>
                    </div>
                    <button onclick="executeSqlImport()" class="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition shadow-md flex items-center justify-center gap-2">
                        <i class="fa-solid fa-bolt"></i> Bắt đầu Import vào Database
                    </button>
                </div>
            </div>

        </div>
    </div>

    <!-- Modal Sửa / Thêm Bản Ghi MySQL -->
    <div id="rowFormModal" class="fixed inset-0 z-[60] hidden bg-slate-950/80 backdrop-blur-sm p-3 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
            <div class="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <h3 id="rowFormTitle" class="font-bold text-sm truncate">Chỉnh sửa dòng dữ liệu</h3>
                <button onclick="closeRowFormModal()" class="w-7 h-7 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div id="rowFormFields" class="p-4 overflow-y-auto space-y-2.5 flex-1"></div>
            <div class="px-4 py-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 bg-slate-50 dark:bg-slate-950/50">
                <button onclick="closeRowFormModal()" class="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-semibold">Hủy</button>
                <button id="rowFormSubmitBtn" class="px-4 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs font-bold shadow-sm">Lưu thay đổi</button>
            </div>
        </div>
    </div>

    <!-- Modal Smart Chunked Upload -->
    <div id="uploadModal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-sm p-4 flex items-center justify-center">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-5 shadow-2xl">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center text-base">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-sm flex items-center gap-1.5">
                            <span>Smart Chunked Upload</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-mono">Max 500MB</span>
                        </h3>
                        <p id="chunkModeSubText" class="text-[11px] text-slate-400">Tự động cắt mảnh 2MB vượt giới hạn Hosting</p>
                    </div>
                </div>
                <button onclick="closeUploadModal()" class="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <label id="uploadDropLabel" class="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-500 bg-slate-50/60 dark:bg-slate-950/50 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer transition text-center group">
                <div class="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center text-xl mb-2.5 group-hover:scale-110 transition">
                    <i class="fa-solid fa-cubes-stacked"></i>
                </div>
                <span class="text-xs font-semibold">Nhấn để chọn tệp hoặc kéo thả vào đây</span>
                <span class="text-[11px] text-slate-400 mt-1">Tự động chia nhỏ và nối tệp trên Server (Không lo lỗi 20MB)</span>
                <input id="uploadInput" type="file" multiple class="hidden" onchange="prepareFilesUpload(this.files)">
            </label>

            <div id="uploadDupBox" class="hidden mt-3.5 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2.5">
                <div class="flex items-start gap-2 text-xs text-amber-400 font-semibold">
                    <i class="fa-solid fa-triangle-exclamation mt-0.5"></i>
                    <div>
                        <div>Phát hiện tệp trùng tên trong thư mục!</div>
                        <div id="uploadDupNames" class="text-[11px] text-slate-300 font-mono mt-0.5 break-all"></div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-2 pt-1">
                    <button onclick="executeUploadWithMode('overwrite')" class="py-2 px-3 rounded-xl bg-rose-500 hover:bg-rose-400 text-white text-xs font-bold transition">
                        Ghi đè tệp cũ
                    </button>
                    <button onclick="executeUploadWithMode('rename')" class="py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition">
                        Giữ cả hai (Đổi tên)
                    </button>
                </div>
            </div>

            <div id="uploadProgressWrap" class="hidden mt-4 space-y-2">
                <div class="flex justify-between items-center text-xs font-medium gap-2">
                    <span id="uploadStatusText" class="text-indigo-400 truncate">Đang tải lên...</span>
                    <span id="uploadPercent" class="font-mono font-bold text-emerald-400 shrink-0">0%</span>
                </div>
                <div class="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div id="uploadBar" class="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 h-full w-0 transition-all duration-150"></div>
                </div>
                <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span id="uploadChunkDetail">Mảnh 0/0</span>
                    <button type="button" onclick="cancelActiveUpload()" class="text-rose-400 hover:text-rose-300 font-sans font-semibold">Hủy tải lên</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Sửa Code -->
    <div id="editorModal" class="fixed inset-0 z-50 hidden bg-slate-950/85 backdrop-blur-sm p-0 sm:p-4 flex items-center justify-center">
        <div class="bg-[#282c34] border-0 sm:border border-slate-700/80 rounded-none sm:rounded-2xl w-full max-w-6xl h-[100dvh] sm:h-[90vh] flex flex-col shadow-2xl overflow-hidden relative">
            <div class="px-3.5 py-2.5 border-b border-slate-800 flex items-center justify-between gap-2 bg-slate-900 text-slate-100">
                <div class="flex items-center gap-2 min-w-0">
                    <i class="fa-solid fa-code text-indigo-400 text-xs"></i>
                    <span id="editorFileName" class="font-bold text-xs sm:text-sm truncate font-mono"></span>
                    <span id="editorCacheBadge" class="hidden text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-mono">0ms Cache</span>
                </div>
                <div class="flex items-center gap-1.5 shrink-0">
                    <button onclick="toggleEditorWrap()" id="wrapBtn" class="px-2.5 py-1 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-[11px] text-indigo-300 font-bold transition" title="Bật/Tắt tự xuống dòng">
                        Wrap: BẬT
                    </button>
                    <button onclick="changeEditorFont(1)" class="hidden sm:flex w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 items-center justify-center text-xs" title="Tăng cỡ chữ">A+</button>
                    <button onclick="changeEditorFont(-1)" class="hidden sm:flex w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 items-center justify-center text-xs" title="Giảm cỡ chữ">A-</button>
                    <button onclick="saveFileContent()" class="px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-sm">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu <span class="hidden md:inline">(Ctrl+S)</span>
                    </button>
                    <button onclick="closeEditor()" class="w-8 h-8 rounded-xl bg-slate-800 hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
            </div>
            <div id="editorLoadingOverlay" class="hidden absolute inset-x-0 top-11 bottom-6 z-20 bg-[#282c34]/90 flex flex-col items-center justify-center gap-2 text-slate-300 text-xs">
                <i class="fa-solid fa-circle-notch fa-spin text-2xl text-indigo-400"></i>
                <span>Đang nạp nội dung tệp tin...</span>
            </div>
            <div id="aceEditor" class="flex-1 w-full"></div>
            <div class="px-3.5 py-1 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-400 font-mono flex items-center justify-between">
                <span id="editorCursorInfo">Dòng 1, Cột 1</span>
                <span id="editorModeInfo">UTF-8 • Word Wrap ON</span>
            </div>
        </div>
    </div>

    <!-- Modal Xem Trước Ảnh -->
    <div id="previewModal" onclick="this.classList.add('hidden')" class="fixed inset-0 z-50 hidden bg-slate-950/85 backdrop-blur-sm p-4 flex flex-col items-center justify-center cursor-zoom-out">
        <img id="previewImg" src="" class="max-w-full max-h-[82vh] rounded-2xl shadow-2xl border border-slate-800 object-contain" alt="Preview">
        <p id="previewCaption" class="mt-3 text-xs text-slate-300 font-medium"></p>
    </div>

    <!-- Toast Thông báo -->
    <div id="toastBox" class="fixed bottom-4 right-4 left-4 sm:left-auto z-[70] flex flex-col items-end gap-2 pointer-events-none"></div>

    <!-- Nạp Module Frontend JS -->
    <script src="app.js?v=<?php echo urlencode($APP_VERSION); ?>"></script>
</body>
</html>